# Batch Image Studio

A Windows-friendly Python GUI for batch image processing: resize, watermark, format convert, and compare results side-by-side. Built with PySide6 and Pillow.

## Quick Start (Windows)

1. Install Python 3.10+ (64-bit).
2. Open **PowerShell** in this folder.
3. Run:
   ```powershell
   scripts\setup_venv.bat
   scripts\run_app.bat
   ```

## Features (Starter)

- Choose **source** and **destination** folders
- **Batch** or **single** image processing
- Resize to **presets** (Etsy, Facebook, Canva, etc.) or **custom** sizes (max-side or exact W×H)
- **Watermark** with PNGs (store multiple, toggle on/off, position auto or manual)
- **Intelligent placement**: auto-chooses the least-busy corner based on edge density
- **Format conversion**: JPG ↔ PNG ↔ WEBP (quality slider, keep metadata toggle)
- **Side-by-side comparison** of original vs processed image
- **Profiles**: save/load processing presets
- **Trial mode**: time-limited trial stored locally; upgrade UI hooks for license key/subscription
- Dark theme by default

## Packaging for Sale

- Freeze with **PyInstaller** (see `build/packaging_notes.md`)
- Wrap with **Inno Setup** for a professional Windows installer
- Add your license flow (online/offline key check) via `trial.py` placeholders

## Folder Layout

```
BatchImageStudio/
├─ assets/
│  ├─ icons/
│  └─ watermarks/          # drop your PNG watermarks here
├─ build/
│  └─ packaging_notes.md
├─ scripts/
│  ├─ setup_venv.bat
│  └─ run_app.bat
├─ src/
│  └─ batch_image_studio/
│     ├─ __init__.py
│     ├─ app.py
│     ├─ image_ops.py
│     ├─ presets.py
│     ├─ settings.py
│     ├─ trial.py
│     └─ resources.py
├─ pyproject.toml
├─ requirements.txt
└─ README.md
```

---

© 2025 Your Company. All rights reserved.

## New: Max file size limiter
- Toggle "Limit file size" and set the MB value (e.g., 20 MB). The app will adapt quality (JPG/WEBP), compress/quantize (PNG), and if needed shrink dimensions stepwise until it fits.

### Pro Features
- **Brand your app**: Pro users can set a custom logo (Tools → Set App Logo). The logo appears in the header.
- **Preset Editor**: Build/duplicate/edit presets, with per-preset size/dimension caps. Saved to `assets/presets/custom_presets.json`.
- **Theme chooser**: Switch between Dark/Light or any `.qss` placed in `assets/themes/`.
- **Updates**: Help → Check for Updates reads a manifest at `https://aidatametrix.com/batch-image-studio/manifest.json` and can fetch new presets/themes or open your latest installer.


## Deliver to client
- Click **Deliver...** to bundle selected outputs into a ZIP and either:
  - Save locally (opens folder)
  - Upload via **transfer.sh** (temporary link copied to clipboard)
  - Upload via **file.io** (temporary link copied to clipboard)
  - Save to your **sync folder** (Dropbox/Drive/OneDrive), then share from the desktop client
- Optional email compose: enter a recipient and the app opens your default mail client with the link in the message.


## Cloud delivery (free + pro options)
- **transfer.sh** and **file.io**: zero-config, temporary links (great for quick shares).
- **S3 / Cloudflare R2**: set access/secret/bucket/endpoint (Tools → Delivery Accounts…). The app uploads the ZIP and returns a **presigned URL** (expires in ~7 days by default).
- **Google Drive**: place OAuth client JSON at `assets/oauth/google_client.json`, then connect via Tools → Delivery Accounts…. The app uploads and sets an anyone-with-link share.
- **Dropbox**: enter App Key/Secret, click “Start OAuth”, paste the returned code, then “Finish with Code”.
- **OneDrive**: supply a Client ID, run Device Flow, enter the shown code in the Microsoft page, then Finish.


## Client address book & proof workflow
- **Clients**: Tools → Client Address Book — store name, email, thumbnail, preferred delivery, and service-specific default folders/paths.
- **Deliver…**: pick a client to auto-fill email and defaults; their thumbnail shows in the dialog.
- **Proof workflow**: tick “Proof workflow” to send watermarked proofs now. The app records a **Proof Job**.
- **Proof Jobs**: Tools → Proof Jobs — when approved, select the job and click **Send Finals** to deliver the unwatermarked finals via the same method.
- **S3/R2 expiry**: set default presigned expiry in Delivery Accounts. You can override per delivery in the dialog.
- **Cloud folders**: in Delivery Accounts (and Clients), set default folder IDs/paths (Drive folder ID, Dropbox path, OneDrive path) to target specific locations.


### Folder tree pickers
In **Delivery Accounts** and **Client Address Book**, use the new **Pick … Folder** buttons to browse and select a target folder:
- Google Drive: interactive tree (needs Drive connection).
- Dropbox: interactive tree (needs Dropbox connection).
- OneDrive: interactive tree via Microsoft Graph (needs OneDrive connection).
The selected IDs/paths are stored as defaults and used by Deliver… / Proof Jobs.
