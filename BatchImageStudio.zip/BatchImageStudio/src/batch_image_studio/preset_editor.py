# src/batch_image_studio/preset_editor.py
from PySide6 import QtWidgets, QtCore
from pathlib import Path
import json

class PresetEditor(QtWidgets.QDialog):
    def __init__(self, assets_dir: Path, existing: dict):
        super().__init__()
        self.setWindowTitle("Preset Editor")
        self.resize(720, 520)
        self.assets_dir = assets_dir
        self.existing = dict(existing)  # copy
        self.model = QtCore.QStringListModel(sorted(self.existing.keys()))
        self.list = QtWidgets.QListView()
        self.list.setModel(self.model)

        form = QtWidgets.QWidget(); grid = QtWidgets.QGridLayout(form)
        self.name = QtWidgets.QLineEdit()
        self.mode = QtWidgets.QComboBox(); self.mode.addItems(["max_side","exact"])
        self.size = QtWidgets.QSpinBox(); self.size.setRange(16, 20000); self.size.setValue(2000)
        self.width = QtWidgets.QSpinBox(); self.width.setRange(16, 20000); self.width.setValue(1080)
        self.height = QtWidgets.QSpinBox(); self.height.setRange(16, 20000); self.height.setValue(1080)
        self.max_mb = QtWidgets.QDoubleSpinBox(); self.max_mb.setDecimals(1); self.max_mb.setRange(0.1, 999.9); self.max_mb.setValue(5.0)
        self.max_w = QtWidgets.QSpinBox(); self.max_w.setRange(16, 20000); self.max_w.setValue(0)
        self.max_h = QtWidgets.QSpinBox(); self.max_h.setRange(16, 20000); self.max_h.setValue(0)

        r=0
        grid.addWidget(QtWidgets.QLabel("Name"), r,0); grid.addWidget(self.name, r,1,1,3); r+=1
        grid.addWidget(QtWidgets.QLabel("Mode"), r,0); grid.addWidget(self.mode, r,1)
        grid.addWidget(QtWidgets.QLabel("Max side"), r,2); grid.addWidget(self.size, r,3); r+=1
        grid.addWidget(QtWidgets.QLabel("Width"), r,0); grid.addWidget(self.width, r,1)
        grid.addWidget(QtWidgets.QLabel("Height"), r,2); grid.addWidget(self.height, r,3); r+=1
        grid.addWidget(QtWidgets.QLabel("Max MB"), r,0); grid.addWidget(self.max_mb, r,1)
        grid.addWidget(QtWidgets.QLabel("Max W"), r,2); grid.addWidget(self.max_w, r,3); r+=1
        grid.addWidget(QtWidgets.QLabel("Max H"), r,2); grid.addWidget(self.max_h, r,3); r+=1

        btn_new = QtWidgets.QPushButton("New")
        btn_dup = QtWidgets.QPushButton("Duplicate")
        btn_del = QtWidgets.QPushButton("Delete")
        btn_save = QtWidgets.QPushButton("Save")
        btn_close = QtWidgets.QPushButton("Close")
        btns = QtWidgets.QHBoxLayout()
        for b in (btn_new, btn_dup, btn_del, btn_save, btn_close): btns.addWidget(b)

        layout = QtWidgets.QHBoxLayout(self)
        layout.addWidget(self.list, 1)
        right = QtWidgets.QVBoxLayout()
        right.addWidget(form, 0)
        right.addStretch(1)
        right.addLayout(btns)
        layout.addLayout(right, 2)

        self.list.selectionModel().currentChanged.connect(self.load_selected)
        btn_new.clicked.connect(self.new_preset)
        btn_dup.clicked.connect(self.duplicate_preset)
        btn_del.clicked.connect(self.delete_preset)
        btn_save.clicked.connect(self.save_presets)
        btn_close.clicked.connect(self.accept)

        if self.model.rowCount() > 0:
            self.list.setCurrentIndex(self.model.index(0))

    def load_selected(self, cur, prev=None):
        if not cur.isValid(): return
        key = self.model.data(cur, 0)
        p = self.existing.get(key, {})
        self.name.setText(key)
        self.mode.setCurrentText(p.get("mode","max_side"))
        self.size.setValue(int(p.get("size", 2000)))
        self.width.setValue(int(p.get("width", 1080)))
        self.height.setValue(int(p.get("height", 1080)))
        self.max_mb.setValue(float(p.get("max_mb", 0) or 0))
        self.max_w.setValue(int(p.get("max_w", 0) or 0))
        self.max_h.setValue(int(p.get("max_h", 0) or 0))

    def new_preset(self):
        name = "New Preset"
        i = 1
        while name in self.existing:
            i += 1
            name = f"New Preset {i}"
        self.existing[name] = {"mode":"max_side","size":2000}
        self.model.setStringList(sorted(self.existing.keys()))
        idx = self.model.stringList().index(name)
        self.list.setCurrentIndex(self.model.index(idx))

    def duplicate_preset(self):
        idx = self.list.currentIndex()
        if not idx.isValid(): return
        key = self.model.data(idx, 0)
        base = dict(self.existing[key])
        name = f"{key} (Copy)"
        i = 1
        while name in self.existing:
            i += 1
            name = f"{key} (Copy {i})"
        self.existing[name] = base
        self.model.setStringList(sorted(self.existing.keys()))

    def delete_preset(self):
        idx = self.list.currentIndex()
        if not idx.isValid(): return
        key = self.model.data(idx, 0)
        self.existing.pop(key, None)
        self.model.setStringList(sorted(self.existing.keys()))

    def save_presets(self):
        # Write current form back to dict
        key = self.list.currentIndex()
        if key.isValid():
            old = self.model.data(key, 0)
            new_name = self.name.text().strip() or old
            p = {
                "mode": self.mode.currentText(),
                "size": self.size.value(),
                "width": self.width.value(),
                "height": self.height.value(),
                "max_mb": float(self.max_mb.value()) if self.max_mb.value()>0 else None,
                "max_w": int(self.max_w.value()) if self.max_w.value()>0 else None,
                "max_h": int(self.max_h.value()) if self.max_h.value()>0 else None,
            }
            # Update key/name
            if new_name != old:
                self.existing.pop(old, None)
            self.existing[new_name] = p
        # Save to assets/presets/custom_presets.json
        out = self.assets_dir / "presets" / "custom_presets.json"
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_text(json.dumps(self.existing, indent=2), encoding="utf-8")
        QtWidgets.QMessageBox.information(self, "Preset Editor", f"Saved to \\n{out}")
        # Refresh list with potentially new names
        self.model.setStringList(sorted(self.existing.keys()))
