# src/batch_image_studio/proof_jobs.py
from __future__ import annotations
from pathlib import Path
import json, time
from appdirs import user_data_dir

APP_NAME = "BatchImageStudio"
COMPANY = "YourCompany"

def _jobs_path() -> Path:
    p = Path(user_data_dir(APP_NAME, COMPANY)); p.mkdir(parents=True, exist_ok=True)
    return p / "proof_jobs.json"

def load_jobs() -> list[dict]:
    p = _jobs_path()
    if p.exists():
        try:
            return json.loads(p.read_text(encoding="utf-8"))
        except Exception:
            return []
    return []

def save_jobs(jobs: list[dict]):
    _jobs_path().write_text(json.dumps(jobs, indent=2), encoding="utf-8")

def add_job(job: dict):
    jobs = load_jobs()
    job["id"] = f"job_{int(time.time()*1000)}"
    jobs.append(job); save_jobs(jobs); return job["id"]

def mark_completed(job_id: str):
    jobs = load_jobs()
    for j in jobs:
        if j.get("id") == job_id:
            j["status"] = "completed"
    save_jobs(jobs)
