# src/batch_image_studio/presets.py
# Common platform presets (edit to your needs)
PRESETS = {
    "Etsy Listing (longest side 2000px)": {"mode": "max_side", "size": 2000},
    "Etsy Listing (longest side 3000px)": {"mode": "max_side", "size": 3000},
    "Etsy Shop Icon (500x500)": {"mode": "exact", "width": 500, "height": 500},
    "Facebook Share (1200x630)": {"mode": "exact", "width": 1200, "height": 630},
    "Facebook Cover (1640x856)": {"mode": "exact", "width": 1640, "height": 856},
    "Instagram Square (1080x1080)": {"mode": "exact", "width": 1080, "height": 1080},
    "Instagram Portrait (1080x1350)": {"mode": "exact", "width": 1080, "height": 1350},
    "Instagram Story/Reel (1080x1920)": {"mode": "exact", "width": 1080, "height": 1920},
    "Canva Presentation (1920x1080)": {"mode": "exact", "width": 1920, "height": 1080},
    "YouTube Thumbnail (1280x720)": {"mode": "exact", "width": 1280, "height": 720},
    "Pinterest Pin (1000x1500)": {"mode": "exact", "width": 1000, "height": 1500},
    "Twitter/X Post (1600x900)": {"mode": "exact", "width": 1600, "height": 900},
    "LinkedIn Share (1200x627)": {"mode": "exact", "width": 1200, "height": 627},
    "Shopify Product (2048x2048)": {"mode": "exact", "width": 2048, "height": 2048},
    "eBay Gallery (1600x1600)": {"mode": "exact", "width": 1600, "height": 1600},
    "Amazon Product (2000x2000)": {"mode": "exact", "width": 2000, "height": 2000},
}

SUPPORTED_FORMATS = [".jpg", ".jpeg", ".png", ".webp", ".bmp", ".tiff"]
DEFAULT_OUTPUT_FORMAT = ".jpg"