# src/batch_image_studio/clients_dialog.py
from PySide6 import QtWidgets, QtGui, QtCore
from pathlib import Path
from .clients import load_clients, save_clients, add_or_update_client, delete_client
from .accounts import load_accounts, get_google_token_path, have_google_drive, have_dropbox, have_onedrive

class ClientsDialog(QtWidgets.QDialog):
    def __init__(self, assets_dir: Path):
        super().__init__()
        self.setWindowTitle("Client Address Book")
        self.resize(720, 520)
        self.assets_dir = assets_dir
        self.model = QtGui.QStandardItemModel(0, 3)
        self.model.setHorizontalHeaderLabels(["Name", "Email", "Preferred Delivery"])
        self.table = QtWidgets.QTableView()
        self.table.setModel(self.model)
        self.table.setSelectionBehavior(QtWidgets.QAbstractItemView.SelectRows)
        self.table.setEditTriggers(QtWidgets.QAbstractItemView.NoEditTriggers)
        self.thumb = QtWidgets.QLabel(); self.thumb.setFixedSize(96,96); self.thumb.setStyleSheet("border:1px solid #444;")
        self.name = QtWidgets.QLineEdit()
        self.email = QtWidgets.QLineEdit()
        self.pref = QtWidgets.QComboBox(); self.pref.addItems(["None","S3/R2","Google Drive","Dropbox","OneDrive","transfer.sh","file.io","Sync folder"])
        self.drive_folder = QtWidgets.QLineEdit(); self.drive_folder.setPlaceholderText("Drive folder ID")
        self.drive_pick = QtWidgets.QPushButton("Pick Drive…")
        self.dbx_folder = QtWidgets.QLineEdit(); self.dbx_folder.setPlaceholderText("Dropbox path, e.g., /Deliveries")
        self.dbx_pick = QtWidgets.QPushButton("Pick Dropbox…")
        self.od_folder = QtWidgets.QLineEdit(); self.od_folder.setPlaceholderText("OneDrive path, e.g., /Deliveries")
        self.od_pick = QtWidgets.QPushButton("Pick OneDrive…")
        self.s3_prefix = QtWidgets.QLineEdit(); self.s3_prefix.setPlaceholderText("S3/R2 key prefix, e.g., deliveries/clientA")
        self.thumb_btn = QtWidgets.QPushButton("Set Thumbnail…")
        self.save_btn = QtWidgets.QPushButton("Save Client")
        self.del_btn = QtWidgets.QPushButton("Delete Client")
        self.close_btn = QtWidgets.QPushButton("Close")

        form = QtWidgets.QFormLayout()
        form.addRow("Name", self.name)
        form.addRow("Email", self.email)
        form.addRow("Preferred", self.pref)
        form.addRow("Drive Folder ID", self.drive_folder)
        form.addRow(self.drive_pick)
        form.addRow("Dropbox Folder", self.dbx_folder)
        form.addRow(self.dbx_pick)
        form.addRow("OneDrive Folder", self.od_folder)
        form.addRow(self.od_pick)
        form.addRow("S3/R2 Prefix", self.s3_prefix)
        form.addRow("Thumbnail", self.thumb_btn)

        left = QtWidgets.QVBoxLayout()
        left.addWidget(self.table, 1)
        right = QtWidgets.QVBoxLayout()
        right.addWidget(self.thumb, 0, QtCore.Qt.AlignLeft)
        right.addLayout(form)
        right.addWidget(self.save_btn, 0, QtCore.Qt.AlignLeft)
        right.addWidget(self.del_btn, 0, QtCore.Qt.AlignLeft)
        right.addStretch(1)
        right.addWidget(self.close_btn, 0, QtCore.Qt.AlignRight)

        layout = QtWidgets.QHBoxLayout(self)
        layout.addLayout(left, 2)
        layout.addLayout(right, 1)

        self.load_table()

        self.table.selectionModel().currentRowChanged.connect(self.load_row)
        self.thumb_btn.clicked.connect(self.pick_thumb)
        self.drive_pick.clicked.connect(self._pick_drive)
        self.dbx_pick.clicked.connect(self._pick_dbx)
        self.od_pick.clicked.connect(self._pick_od)
        self.save_btn.clicked.connect(self.save_client)
        self.del_btn.clicked.connect(self.delete_client)
        self.close_btn.clicked.connect(self.accept)

    def load_table(self):
        self.model.removeRows(0, self.model.rowCount())
        for c in load_clients():
            self._append_row(c)

    def _append_row(self, c: dict):
        r = [QtGui.QStandardItem(c.get("name","")), QtGui.QStandardItem(c.get("email","")), QtGui.QStandardItem(c.get("preferred","None"))]
        self.model.appendRow(r)

    def load_row(self, cur, prev):
        if not cur.isValid(): return
        row = cur.row()
        email = self.model.item(row, 1).text()
        for c in load_clients():
            if c.get("email","").lower() == email.lower():
                self.name.setText(c.get("name",""))
                self.email.setText(c.get("email",""))
                self.pref.setCurrentText(c.get("preferred","None") or "None")
                self.drive_folder.setText(c.get("drive_folder","") or "")
                self.dbx_folder.setText(c.get("dbx_folder","") or "")
                self.od_folder.setText(c.get("od_folder","") or "")
                self.s3_prefix.setText(c.get("s3_prefix","") or "")
                thumb = c.get("thumbnail","")
                if thumb and Path(thumb).exists():
                    pm = QtGui.QPixmap(thumb).scaled(96,96, QtCore.Qt.KeepAspectRatio, QtCore.Qt.SmoothTransformation)
                else:
                    pm = QtGui.QPixmap()
                self.thumb.setPixmap(pm)
                break

    def pick_thumb(self):
        f, _ = QtWidgets.QFileDialog.getOpenFileName(self, "Choose thumbnail", str(Path.home()), "Images (*.png *.jpg *.jpeg *.webp)")
        if f:
            pm = QtGui.QPixmap(f).scaled(96,96, QtCore.Qt.KeepAspectRatio, QtCore.Qt.SmoothTransformation)
            self.thumb.setPixmap(pm)
            self.thumb.setProperty("thumb_path", f)

    def save_client(self):
        c = {
            "name": self.name.text().strip(),
            "email": self.email.text().strip(),
            "preferred": self.pref.currentText(),
            "drive_folder": self.drive_folder.text().strip() or None,
            "dbx_folder": self.dbx_folder.text().strip() or None,
            "od_folder": self.od_folder.text().strip() or None,
            "s3_prefix": self.s3_prefix.text().strip() or None,
            "thumbnail": self.thumb.property("thumb_path") or None,
        }
        if not c["email"]:
            QtWidgets.QMessageBox.warning(self, "Client", "Email is required (used as unique ID).")
            return
        add_or_update_client(c)
        self.load_table()
        QtWidgets.QMessageBox.information(self, "Client", "Saved.")

    def delete_client(self):
        email = self.email.text().strip()
        if not email: return
        delete_client(email)
        self.load_table()


    def _pick_drive(self):
        try:
            if not have_google_drive():
                QtWidgets.QMessageBox.information(self, "Drive", "Connect Google Drive in Delivery Accounts first.")
                return
            from google.oauth2.credentials import Credentials
            from .cloud_folder_picker import CloudFolderPicker, DriveBackend
            creds = Credentials.from_authorized_user_file(str(get_google_token_path()), scopes=["https://www.googleapis.com/auth/drive.file"])
            dlg = CloudFolderPicker(DriveBackend(creds))
            if dlg.exec():
                fid, name = dlg.selected_folder_id()
                if fid: self.drive_folder.setText(fid)
        except Exception as e:
            QtWidgets.QMessageBox.warning(self, "Drive", f"Failed: {e}")

    def _pick_dbx(self):
        try:
            acc = load_accounts().get("dropbox", {})
            if not acc.get("access_token"):
                QtWidgets.QMessageBox.information(self, "Dropbox", "Connect Dropbox in Delivery Accounts first.")
                return
            import dropbox
            from .cloud_folder_picker import CloudFolderPicker, DropboxBackend
            dbx = dropbox.Dropbox(acc["access_token"])
            dlg = CloudFolderPicker(DropboxBackend(dbx))
            if dlg.exec():
                fid, name = dlg.selected_folder_id()
                if fid is not None: self.dbx_folder.setText(fid)
        except Exception as e:
            QtWidgets.QMessageBox.warning(self, "Dropbox", f"Failed: {e}")

    def _pick_od(self):
        try:
            acc = load_accounts().get("onedrive", {})
            if not acc.get("access_token"):
                QtWidgets.QMessageBox.information(self, "OneDrive", "Connect OneDrive in Delivery Accounts first.")
                return
            from .cloud_folder_picker import CloudFolderPicker, OneDriveBackend
            dlg = CloudFolderPicker(OneDriveBackend(acc["access_token"]))
            if dlg.exec():
                fid, name = dlg.selected_folder_id()
                if fid: self.od_folder.setText(fid)
        except Exception as e:
            QtWidgets.QMessageBox.warning(self, "OneDrive", f"Failed: {e}")
