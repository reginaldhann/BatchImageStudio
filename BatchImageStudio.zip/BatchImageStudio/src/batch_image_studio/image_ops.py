# src/batch_image_studio/image_ops.py
from PIL import Image, ImageFilter, ImageOps, ImageStat
from pathlib import Path
from typing import Optional, Tuple, Dict, Any
from io import BytesIO

def ensure_dir(p: Path):
    p.parent.mkdir(parents=True, exist_ok=True)

def _cap_dimensions(img: Image.Image, max_w: int | None, max_h: int | None) -> tuple[Image.Image, bool]:
    if not max_w and not max_h:
        return img, False
    w, h = img.size
    cap_w = max_w or w
    cap_h = max_h or h
    if w <= cap_w and h <= cap_h:
        return img, False
    scale = min(cap_w / w, cap_h / h)
    new = (max(1, int(w * scale)), max(1, int(h * scale)))
    return img.resize(new, Image.Resampling.LANCZOS), True

def resize_image(img: Image.Image, mode: str, *, size: int = None, width: int = None, height: int = None) -> Image.Image:
    if mode == "max_side" and size:
        w, h = img.size
        scale = size / max(w, h)
        if scale < 1.0:
            new = (int(w * scale), int(h * scale))
            return img.resize(new, Image.Resampling.LANCZOS)
        return img.copy()
    elif mode == "exact" and width and height:
        return ImageOps.fit(img, (width, height), Image.Resampling.LANCZOS)
    else:
        return img.copy()

def convert_format(path: Path, desired_ext: str) -> Path:
    return path.with_suffix(desired_ext)

def auto_watermark_position(base: Image.Image, wm: Image.Image, margin: int = 12) -> Tuple[int, int]:
    bw, bh = base.size
    ww, wh = wm.size
    corners = {
        "tl": (margin, margin),
        "tr": (bw - ww - margin, margin),
        "bl": (margin, bh - wh - margin),
        "br": (bw - ww - margin, bh - wh - margin),
    }
    scores = {}
    for name, (x, y) in corners.items():
        box = (x, y, x + ww, y + wh)
        region = base.crop(box).filter(ImageFilter.FIND_EDGES).convert("L")
        score = float(ImageStat.Stat(region).mean[0])
        scores[name] = score
    best = min(scores, key=lambda k: scores[k])
    return corners[best]

def apply_watermark(base: Image.Image, watermark: Image.Image, position: Optional[str] = "auto", opacity: float = 0.25, scale: float = 0.25):
    bw, bh = base.size
    target = int(min(bw, bh) * scale)
    wm = watermark.convert("RGBA")
    wmw, wmh = wm.size
    if max(wmw, wmh) != target:
        if wmw >= wmh:
            new = (target, int(wmh * target / wmw))
        else:
            new = (int(wmw * target / wmh), target)
        wm = wm.resize(new, Image.Resampling.LANCZOS)
    alpha = wm.split()[3].point(lambda a: int(a * opacity))
    wm.putalpha(alpha)

    if position == "auto" or position is None:
        x, y = auto_watermark_position(base, wm)
    else:
        margin = 12
        x = margin if "left" in position else bw - wm.size[0] - margin
        y = margin if "top" in position else bh - wm.size[1] - margin

    out = base.convert("RGBA")
    out.alpha_composite(wm, dest=(x, y))
    return out.convert("RGB")

def _save_to_buffer(img: Image.Image, fmt_ext: str, *, quality: int, keep_metadata: bool, extra=None) -> BytesIO:
    buf = BytesIO()
    fmt = "JPEG" if fmt_ext.lower() in [".jpg", ".jpeg"] else "PNG" if fmt_ext.lower() == ".png" else "WEBP" if fmt_ext.lower() == ".webp" else None
    params = dict()
    if fmt in ["JPEG", "WEBP"]:
        params["quality"] = quality
    if fmt == "PNG":
        params["optimize"] = True
        if extra and extra.get("compress_level") is not None:
            params["compress_level"] = extra["compress_level"]
    if keep_metadata and "exif" in img.info:
        params["exif"] = img.info["exif"]
    img.save(buf, format=fmt, **params)
    return buf

def _try_reduce_png(img: Image.Image, keep_metadata: bool, target_bytes: int):
    for colors in [256, 128, 64]:
        quant = img.convert("RGB").quantize(colors=colors, method=Image.FASTOCTREE).convert("RGBA")
        for level in [9, 6, 3]:
            buf = _save_to_buffer(quant, ".png", quality=95, keep_metadata=keep_metadata, extra={"compress_level": level})
            if buf.getbuffer().nbytes <= target_bytes:
                return buf, buf.getbuffer().nbytes, {"png_colors": colors, "png_compress_level": level}
    buf = _save_to_buffer(img, ".png", quality=95, keep_metadata=keep_metadata, extra={"compress_level": 9})
    return buf, buf.getbuffer().nbytes, {"png_colors": None, "png_compress_level": 9}

def _save_under_size(img: Image.Image, fmt_ext: str, *, quality: int, keep_metadata: bool, target_bytes: int | None, min_side: int = 256):
    info: Dict[str, Any] = {"limited": False, "quality": quality, "resizes": 0, "final_size": img.size, "png_colors": None}
    current = img
    q = quality

    def fits(b):
        return target_bytes is None or b.getbuffer().nbytes <= target_bytes

    while True:
        if fmt_ext.lower() in [".jpg", ".jpeg", ".webp"]:
            for q_try in list(range(q, 39, -5)) + [38, 35, 32]:
                buf = _save_to_buffer(current, fmt_ext, quality=q_try, keep_metadata=keep_metadata)
                if fits(buf):
                    info["limited"] = (q_try != quality or info["resizes"] > 0)
                    info["quality"] = q_try
                    info["final_size"] = current.size
                    return buf, info
            new_w = int(current.size[0] * 0.9)
            new_h = int(current.size[1] * 0.9)
            if min(new_w, new_h) < min_side:
                buf = _save_to_buffer(current, fmt_ext, quality=32, keep_metadata=keep_metadata)
                info["limited"] = True
                info["quality"] = 32
                info["final_size"] = current.size
                return buf, info
            current = current.resize((new_w, new_h), Image.Resampling.LANCZOS)
            info["resizes"] += 1
            q = 85
        elif fmt_ext.lower() == ".png":
            buf, _, png_info = _try_reduce_png(current, keep_metadata, target_bytes or 10**12)
            if fits(buf):
                info.update({"limited": True, "quality": 95, "final_size": current.size, **png_info})
                return buf, info
            new_w = int(current.size[0] * 0.9)
            new_h = int(current.size[1] * 0.9)
            if min(new_w, new_h) < min_side:
                info.update({"limited": True, "quality": 95, "final_size": current.size, **png_info})
                return buf, info
            current = current.resize((new_w, new_h), Image.Resampling.LANCZOS)
            info["resizes"] += 1
        else:
            buf = _save_to_buffer(current, fmt_ext, quality=quality, keep_metadata=keep_metadata)
            info["final_size"] = current.size
            return buf, info

def process_image(
    in_path: Path,
    out_path: Path,
    *,
    resize_mode: str = "max_side",
    max_side: int = 2000,
    exact_w: int = None,
    exact_h: int = None,
    fmt_ext: str = ".jpg",
    quality: int = 90,
    keep_metadata: bool = True,
    watermark_path: Optional[Path] = None,
    watermark_opacity: float = 0.25,
    watermark_scale: float = 0.25,
    watermark_position: Optional[str] = "auto",
    max_filesize_bytes: Optional[int] = None,
    cap_max_w: Optional[int] = None,
    cap_max_h: Optional[int] = None,
) -> dict:
    im = Image.open(in_path)
    im = im.convert("RGB")
    original_size = im.size

    if resize_mode == "max_side":
        im = resize_image(im, "max_side", size=max_side)
    elif resize_mode == "exact" and exact_w and exact_h:
        im = resize_image(im, "exact", width=exact_w, height=exact_h)

    im, was_capped = _cap_dimensions(im, cap_max_w, cap_max_h)

    if watermark_path and watermark_path.exists():
        wm = Image.open(watermark_path)
        im = apply_watermark(im, wm, position=watermark_position, opacity=watermark_opacity, scale=watermark_scale)

    ensure_dir(out_path)
    info: Dict[str, Any] = {
        "input_name": in_path.name,
        "output_name": out_path.with_suffix(fmt_ext).name,
        "orig_w": original_size[0],
        "orig_h": original_size[1],
        "final_w": im.size[0],
        "final_h": im.size[1],
        "format": fmt_ext.lower(),
        "quality_used": quality,
        "limited_by_filesize": False,
        "downscale_steps": 0,
        "was_capped_by_max_dim": was_capped,
        "bytes_before": Path(in_path).stat().st_size if in_path.exists() else None,
        "bytes_after": None,
        "notes": "",
    }

    if max_filesize_bytes:
        buf, lim_info = _save_under_size(im, fmt_ext, quality=quality, keep_metadata=keep_metadata, target_bytes=max_filesize_bytes)
        with open(out_path.with_suffix(fmt_ext), "wb") as f:
            f.write(buf.getbuffer())
        info["quality_used"] = lim_info.get("quality", quality)
        info["limited_by_filesize"] = lim_info.get("limited", False)
        info["downscale_steps"] = lim_info.get("resizes", 0)
        info["final_w"], info["final_h"] = lim_info.get("final_size", im.size)
        if lim_info.get("png_colors") is not None:
            info["notes"] += f"PNG quantized to {lim_info['png_colors']} colors. "
    else:
        save_params = {}
        if fmt_ext.lower() in [".jpg", ".jpeg", ".webp"]:
            save_params["quality"] = quality
        if keep_metadata and "exif" in im.info:
            save_params["exif"] = im.info["exif"]
        im.save(out_path.with_suffix(fmt_ext), **save_params)

    info["bytes_after"] = out_path.with_suffix(fmt_ext).stat().st_size if out_path.with_suffix(fmt_ext).exists() else None
    if info["limited_by_filesize"] or was_capped:
        info["notes"] += "Limiter/cap applied."
    return info
