# src/batch_image_studio/accounts.py
from __future__ import annotations
from pathlib import Path
import json, webbrowser, os

from appdirs import user_data_dir

APP_NAME = "BatchImageStudio"
COMPANY = "YourCompany"

def _store_path() -> Path:
    p = Path(user_data_dir(APP_NAME, COMPANY))
    p.mkdir(parents=True, exist_ok=True)
    return p / "cloud_accounts.json"

def load_accounts() -> dict:
    p = _store_path()
    if p.exists():
        try:
            return json.loads(p.read_text(encoding="utf-8"))
        except Exception:
            return {}
    return {}

def save_accounts(data: dict):
    _store_path().write_text(json.dumps(data, indent=2), encoding="utf-8")

# ---- S3 / R2 ----
def set_s3_config(*, name: str, access_key: str, secret_key: str, bucket: str, region: str = "auto", endpoint_url: str | None = None):
    acc = load_accounts()
    acc["s3"] = {"name": name, "access_key": access_key, "secret_key": secret_key, "bucket": bucket, "region": region, "endpoint_url": endpoint_url}
    save_accounts(acc)

def get_s3_config() -> dict | None:
    return load_accounts().get("s3")

# ---- Google Drive ----
# For Drive, place your OAuth client in assets/oauth/google_client.json (Desktop app type).
# We'll save tokens under app data.
def get_google_token_path() -> Path:
    p = Path(user_data_dir(APP_NAME, COMPANY))
    p.mkdir(parents=True, exist_ok=True)
    return p / "google_drive_token.json"

def have_google_drive() -> bool:
    return get_google_token_path().exists()

def start_google_oauth(client_json_path: Path) -> tuple[bool, str]:
    try:
        from google_auth_oauthlib.flow import InstalledAppFlow
        SCOPES = ["https://www.googleapis.com/auth/drive.file"]
        flow = InstalledAppFlow.from_client_secrets_file(str(client_json_path), SCOPES)
        creds = flow.run_local_server(port=0)
        get_google_token_path().write_text(creds.to_json(), encoding="utf-8")
        return True, "Connected to Google Drive."
    except Exception as e:
        return False, str(e)

# ---- Dropbox ----
def have_dropbox() -> bool:
    acc = load_accounts()
    return bool(acc.get("dropbox", {}).get("access_token"))

def start_dropbox_oauth(app_key: str, app_secret: str) -> tuple[bool, str]:
    try:
        import dropbox
        auth_flow = dropbox.DropboxOAuth2FlowNoRedirect(app_key, app_secret)
        authorize_url = auth_flow.start()
        webbrowser.open(authorize_url)
        # User will paste code in the app's UI; we'll finish in the dialog via finish_dropbox_oauth
        return True, authorize_url
    except Exception as e:
        return False, str(e)

def finish_dropbox_oauth(app_key: str, app_secret: str, code: str) -> tuple[bool, str]:
    try:
        import dropbox
        auth_flow = dropbox.DropboxOAuth2FlowNoRedirect(app_key, app_secret)
        oauth_result = auth_flow.finish(code.strip())
        acc = load_accounts()
        acc["dropbox"] = {"access_token": oauth_result.access_token}
        save_accounts(acc)
        return True, "Connected to Dropbox."
    except Exception as e:
        return False, str(e)

# ---- OneDrive (Microsoft Graph, personal/OneDrive) ----
def have_onedrive() -> bool:
    acc = load_accounts()
    return bool(acc.get("onedrive", {}).get("access_token"))

def start_onedrive_device_flow(client_id: str, tenant: str = "consumers") -> tuple[bool, dict | str]:
    try:
        import msal
        app = msal.PublicClientApplication(client_id=client_id, authority=f"https://login.microsoftonline.com/{tenant}")
        flow = app.initiate_device_flow(scopes=["Files.ReadWrite", "offline_access"])
        if "user_code" not in flow:
            return False, "Failed to start device flow."
        return True, flow
    except Exception as e:
        return False, str(e)

def finish_onedrive_device_flow(client_id: str, flow: dict, tenant: str = "consumers") -> tuple[bool, str]:
    try:
        import msal, time
        app = msal.PublicClientApplication(client_id=client_id, authority=f"https://login.microsoftonline.com/{tenant}")
        result = app.acquire_token_by_device_flow(flow)
        if "access_token" in result:
            acc = load_accounts()
            acc["onedrive"] = {
                "access_token": result["access_token"],
                "refresh_token": result.get("refresh_token"),
                "client_id": client_id,
                "tenant": tenant,
            }
            save_accounts(acc)
            return True, "Connected to OneDrive."
        return False, str(result)
    except Exception as e:
        return False, str(e)
