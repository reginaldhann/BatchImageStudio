# src/batch_image_studio/updater.py
"""
Updater scaffold.
"""
import sys, tempfile, zipfile, os, webbrowser
from pathlib import Path
import requests

APP_VERSION = "0.1.1"  # bump as you release

def fetch_json(url: str):
    try:
        r = requests.get(url, timeout=10)
        if r.ok:
            return r.json()
    except Exception:
        return None
    return None

def is_frozen() -> bool:
    return getattr(sys, 'frozen', False)

def apply_zip_to_folder(url: str, dest: Path) -> bool:
    try:
        r = requests.get(url, timeout=20)
        r.raise_for_status()
        tmp = Path(tempfile.gettempdir()) / "bis_update.zip"
        tmp.write_bytes(r.content)
        with zipfile.ZipFile(tmp, "r") as z:
            z.extractall(dest)
        return True
    except Exception:
        return False

def check_for_updates(manifest_url: str, assets_dir: Path):
    data = fetch_json(manifest_url)
    if not data:
        return False, "Could not reach update server."
    latest = data.get("version", APP_VERSION)
    if latest == APP_VERSION:
        return False, "You're up to date."
    ok_msgs = []
    if data.get("presets_url"):
        if apply_zip_to_folder(data["presets_url"], assets_dir / "presets"):
            ok_msgs.append("Presets updated")
    if data.get("themes_url"):
        if apply_zip_to_folder(data["themes_url"], assets_dir / "themes"):
            ok_msgs.append("Themes updated")
    if data.get("installer_url"):
        webbrowser.open(data["installer_url"])
        ok_msgs.append("Opened installer page")
    return True, "; ".join(ok_msgs) or "Update available."
