# src/batch_image_studio/accounts_dialog.py
from PySide6 import QtWidgets, QtCore
from pathlib import Path
from .accounts import (
    get_google_token_path,
    load_accounts, save_accounts,
    set_s3_config, get_s3_config,
    start_google_oauth, have_google_drive,
    start_dropbox_oauth, finish_dropbox_oauth, have_dropbox,
    start_onedrive_device_flow, finish_onedrive_device_flow, have_onedrive
)

class AccountsDialog(QtWidgets.QDialog):
    def __init__(self, assets_dir: Path):
        super().__init__()
        self.setWindowTitle("Delivery Accounts")
        self.resize(680, 540)
        self.assets_dir = assets_dir
        tabs = QtWidgets.QTabWidget(self)

        # S3/R2 tab
        self.s3_name = QtWidgets.QLineEdit()
        self.s3_access = QtWidgets.QLineEdit()
        self.s3_secret = QtWidgets.QLineEdit(); self.s3_secret.setEchoMode(QtWidgets.QLineEdit.Password)
        self.s3_bucket = QtWidgets.QLineEdit()
        self.s3_region = QtWidgets.QLineEdit("auto")
        self.s3_endpoint = QtWidgets.QLineEdit()  # R2 endpoint optional
        self.s3_expiry = QtWidgets.QSpinBox(); self.s3_expiry.setRange(3600, 30*24*3600); self.s3_expiry.setValue(7*24*3600)
        s3_form = QtWidgets.QFormLayout()
        s3_form.addRow("Profile name", self.s3_name)
        s3_form.addRow("Access key", self.s3_access)
        s3_form.addRow("Secret key", self.s3_secret)
        s3_form.addRow("Bucket", self.s3_bucket)
        s3_form.addRow("Region", self.s3_region)
        s3_form.addRow("Endpoint URL (R2)", self.s3_endpoint)
        s3_form.addRow("Presigned Expiry (seconds)", self.s3_expiry)
        s3_box = QtWidgets.QWidget(); s3_box.setLayout(s3_form)
        tabs.addTab(s3_box, "S3 / R2")
        s3_btn = QtWidgets.QPushButton("Save S3/R2 Config")

        # Google Drive tab
        self.g_hint = QtWidgets.QLabel("Place Google OAuth client JSON at assets/oauth/google_client.json")
        self.g_connect = QtWidgets.QPushButton("Connect Google Drive")
        self.g_folder = QtWidgets.QLineEdit(); self.g_folder.setPlaceholderText("Default folder ID (optional)")
        g_box = QtWidgets.QVBoxLayout()
        g_box.addWidget(self.g_hint)
        g_box.addWidget(self.g_connect, 0, QtCore.Qt.AlignLeft)
        g_box.addWidget(QtWidgets.QLabel("Default folder ID:"))
        g_box.addWidget(self.g_folder)
        self.g_pick = QtWidgets.QPushButton("Pick Drive Folder…")
        g_box.addWidget(self.g_pick, 0, QtCore.Qt.AlignLeft)
        g_wrap = QtWidgets.QWidget(); g_wrap.setLayout(g_box)
        tabs.addTab(g_wrap, "Google Drive")

        # Dropbox tab
        self.dbx_app_key = QtWidgets.QLineEdit()
        self.dbx_app_secret = QtWidgets.QLineEdit(); self.dbx_app_secret.setEchoMode(QtWidgets.QLineEdit.Password)
        self.dbx_start = QtWidgets.QPushButton("Start Dropbox OAuth")
        self.dbx_code = QtWidgets.QLineEdit()
        self.dbx_finish = QtWidgets.QPushButton("Finish with Code")
        dbx_form = QtWidgets.QFormLayout()
        dbx_form.addRow("App Key", self.dbx_app_key)
        dbx_form.addRow("App Secret", self.dbx_app_secret)
        dbx_form.addRow(self.dbx_start)
        dbx_form.addRow("Paste Code", self.dbx_code)
        dbx_form.addRow(self.dbx_finish)
        self.dbx_pick = QtWidgets.QPushButton("Pick Dropbox Folder…")
        dbx_form.addRow(self.dbx_pick)
        dbx_wrap = QtWidgets.QWidget(); dbx_wrap.setLayout(dbx_form)
        tabs.addTab(dbx_wrap, "Dropbox")

        # OneDrive tab (device code)
        self.od_client_id = QtWidgets.QLineEdit()
        self.od_tenant = QtWidgets.QLineEdit("consumers")
        self.od_start = QtWidgets.QPushButton("Start Device Flow")
        self.od_msg = QtWidgets.QLabel("")
        self.od_finish = QtWidgets.QPushButton("Finish Login")
        od_form = QtWidgets.QFormLayout()
        od_form.addRow("Client ID", self.od_client_id)
        od_form.addRow("Tenant (consumers/organizations/<id>)", self.od_tenant)
        od_form.addRow(self.od_start)
        od_form.addRow(self.od_msg)
        od_form.addRow(self.od_finish)
        self.od_pick = QtWidgets.QPushButton("Pick OneDrive Folder…")
        od_form.addRow(self.od_pick)
        od_wrap = QtWidgets.QWidget(); od_wrap.setLayout(od_form)
        tabs.addTab(od_wrap, "OneDrive")

        # Main layout
        v = QtWidgets.QVBoxLayout(self)
        v.addWidget(tabs)
        v.addWidget(s3_btn)

        # Load existing s3 config
        cfg = get_s3_config() or {}
        self.s3_name.setText(cfg.get("name",""))
        self.s3_access.setText(cfg.get("access_key",""))
        self.s3_secret.setText(cfg.get("secret_key",""))
        self.s3_bucket.setText(cfg.get("bucket",""))
        self.s3_region.setText(cfg.get("region","auto"))
        self.s3_endpoint.setText(cfg.get("endpoint_url","") or "")
        self.s3_expiry.setValue(int((load_accounts().get("s3",{}) or {}).get("expires_sec", 7*24*3600)))

        # Signals
        s3_btn.clicked.connect(self.save_s3)
        self.g_connect.clicked.connect(self.connect_google)
        self.g_pick.clicked.connect(self.pick_drive_folder)
        # Persist Drive default folder
        acc = load_accounts(); self.g_folder.setText((acc.get("gdrive") or {}).get("folder_id",""))
        self.dbx_start.clicked.connect(self.start_dbx)
        self.dbx_finish.clicked.connect(self.finish_dbx)
        self.dbx_pick.clicked.connect(self.pick_dbx_folder)
        self.od_start.clicked.connect(self.start_od)
        self.od_finish.clicked.connect(self.finish_od)
        self.od_pick.clicked.connect(self.pick_od_folder)

        self._od_flow = None

    def save_s3(self):
        set_s3_config(
            name=self.s3_name.text().strip(),
            access_key=self.s3_access.text().strip(),
            secret_key=self.s3_secret.text().strip(),
            bucket=self.s3_bucket.text().strip(),
            region=self.s3_region.text().strip(),
            endpoint_url=(self.s3_endpoint.text().strip() or None),
        )
        acc = load_accounts(); acc["s3"]["expires_sec"] = int(self.s3_expiry.value()); save_accounts(acc)
        QtWidgets.QMessageBox.information(self, "S3/R2", "Saved.")

    def connect_google(self):
        p = self.assets_dir / "oauth" / "google_client.json"
        if not p.exists():
            QtWidgets.QMessageBox.warning(self, "Google Drive", f"Missing client JSON:\n{p}")
            return
        ok, msg = start_google_oauth(p)
        QtWidgets.QMessageBox.information(self, "Google Drive", msg if ok else f"Failed: {msg}")

    def start_dbx(self):
        ok, msg = start_dropbox_oauth(self.dbx_app_key.text().strip(), self.dbx_app_secret.text().strip())
        if ok:
            QtWidgets.QMessageBox.information(self, "Dropbox", f"Opened browser. If not, visit:\n{msg}")
        else:
            QtWidgets.QMessageBox.warning(self, "Dropbox", f"Failed: {msg}")

    def finish_dbx(self):
        ok, msg = finish_dropbox_oauth(self.dbx_app_key.text().strip(), self.dbx_app_secret.text().strip(), self.dbx_code.text().strip())
        QtWidgets.QMessageBox.information(self, "Dropbox", msg if ok else f"Failed: {msg}")

    def start_od(self):
        ok, flow_or_msg = start_onedrive_device_flow(self.od_client_id.text().strip(), self.od_tenant.text().strip() or "consumers")
        if ok:
            self._od_flow = flow_or_msg
            self.od_msg.setText(f"Go to {self._od_flow.get('verification_uri')} and enter code: {self._od_flow.get('user_code')}")
        else:
            QtWidgets.QMessageBox.warning(self, "OneDrive", f"Failed: {flow_or_msg}")

    def finish_od(self):
        if not self._od_flow:
            QtWidgets.QMessageBox.information(self, "OneDrive", "Start the device flow first.")
            return
        ok, msg = finish_onedrive_device_flow(self.od_client_id.text().strip(), self._od_flow, self.od_tenant.text().strip() or "consumers")
        QtWidgets.QMessageBox.information(self, "OneDrive", msg if ok else f"Failed: {msg}")


    def on_close(self):
        acc = load_accounts()
        g = acc.get("gdrive") or {}
        g["folder_id"] = self.g_folder.text().strip()
        acc["gdrive"] = g
        save_accounts(acc)
        self.accept()


    def pick_drive_folder(self):
        try:
            from google.oauth2.credentials import Credentials
            from .cloud_folder_picker import CloudFolderPicker, DriveBackend
            creds = Credentials.from_authorized_user_file(str(get_google_token_path()), scopes=["https://www.googleapis.com/auth/drive.file"])
            dlg = CloudFolderPicker(DriveBackend(creds))
            if dlg.exec():
                fid, name = dlg.selected_folder_id()
                if fid:
                    self.g_folder.setText(fid)
        except Exception as e:
            QtWidgets.QMessageBox.warning(self, "Google Drive", f"Failed: {e}")


    def pick_dbx_folder(self):
        try:
            import dropbox
            from .cloud_folder_picker import CloudFolderPicker, DropboxBackend
            acc = load_accounts().get("dropbox", {})
            if not acc.get("access_token"):
                QtWidgets.QMessageBox.information(self, "Dropbox", "Connect Dropbox first.")
                return
            dbx = dropbox.Dropbox(acc["access_token"])
            dlg = CloudFolderPicker(DropboxBackend(dbx))
            if dlg.exec():
                fid, name = dlg.selected_folder_id()
                if fid is not None:
                    # Store path in Dropbox defaults within accounts
                    a = load_accounts(); d = a.get("dropbox", {}); d["folder_path"] = fid; a["dropbox"] = d; save_accounts(a)
                    QtWidgets.QMessageBox.information(self, "Dropbox", f"Default folder set to: {fid}")
        except Exception as e:
            QtWidgets.QMessageBox.warning(self, "Dropbox", f"Failed: {e}")


    def pick_od_folder(self):
        try:
            from .cloud_folder_picker import CloudFolderPicker, OneDriveBackend
            acc = load_accounts().get("onedrive", {})
            if not acc.get("access_token"):
                QtWidgets.QMessageBox.information(self, "OneDrive", "Connect OneDrive first.")
                return
            dlg = CloudFolderPicker(OneDriveBackend(acc["access_token"]))
            if dlg.exec():
                fid, name = dlg.selected_folder_id()
                if fid:
                    # Store in accounts
                    a = load_accounts(); o = a.get("onedrive", {}); o["folder_id"] = fid; a["onedrive"] = o; save_accounts(a)
                    QtWidgets.QMessageBox.information(self, "OneDrive", f"Default folder set.")
        except Exception as e:
            QtWidgets.QMessageBox.warning(self, "OneDrive", f"Failed: {e}")
