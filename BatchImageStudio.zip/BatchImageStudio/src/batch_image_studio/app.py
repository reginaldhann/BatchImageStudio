# src/batch_image_studio/app.py
import sys, os, csv, datetime, tempfile
from pathlib import Path
from typing import Optional
from PySide6 import QtWidgets, QtGui, QtCore
import qdarktheme

from .resources import WATERMARKS_DIR, ASSETS_DIR
from .presets import PRESETS, SUPPORTED_FORMATS, DEFAULT_OUTPUT_FORMAT, load_external_presets
from .settings import load_settings, save_settings
from .trial import get_trial_status, apply_license, is_pro
from .image_ops import process_image
from .updater import check_for_updates
from .accounts_dialog import AccountsDialog
from .clients_dialog import ClientsDialog
from .clients import load_clients
from .jobs_dialog import JobsDialog
from .proof_jobs import add_job
from .accounts import load_accounts, get_google_token_path, have_google_drive, have_dropbox, have_onedrive
from .deliver_dialog import DeliverDialog
from .deliver import local_zip, transfer_sh, file_io, save_to_sync, s3_presign_and_upload, gdrive_upload_zip, dropbox_upload_zip, onedrive_upload_zip
from .preset_editor import PresetEditor

APP_VERSION = "0.1.2"

def load_qss_themes(assets_dir: Path):
    themes = []
    tdir = assets_dir / "themes"
    if tdir.exists():
        for qss in sorted(tdir.glob("*.qss")):
            themes.append(qss)
    return themes

class ImageListModel(QtCore.QAbstractListModel):
    def __init__(self, paths):
        super().__init__()
        self.paths = paths
    def data(self, index, role):
        if role == QtCore.Qt.DisplayRole:
            return str(self.paths[index.row()].name)
    def rowCount(self, parent=None):
        return len(self.paths)
    def get(self, row): return self.paths[row]
    def setDataSet(self, paths):
        self.beginResetModel()
        self.paths = paths
        self.endResetModel()

class PreviewWidget(QtWidgets.QWidget):
    def __init__(self):
        super().__init__()
        self.setLayout(QtWidgets.QHBoxLayout())
        self.left = QtWidgets.QLabel("Original")
        self.left.setAlignment(QtCore.Qt.AlignCenter)
        self.right = QtWidgets.QLabel("Processed")
        self.right.setAlignment(QtCore.Qt.AlignCenter)
        self.left.setMinimumSize(320, 240)
        self.right.setMinimumSize(320, 240)
        self.layout().addWidget(self.left, 1)
        self.layout().addWidget(self.right, 1)
    def set_pixmaps(self, left: QtGui.QPixmap, right: QtGui.QPixmap):
        self.left.setPixmap(left.scaled(self.left.size(), QtCore.Qt.KeepAspectRatio, QtCore.Qt.SmoothTransformation))
        self.right.setPixmap(right.scaled(self.right.size(), QtCore.Qt.KeepAspectRatio, QtCore.Qt.SmoothTransformation))
    def resizeEvent(self, e):
        if self.left.pixmap():
            self.left.setPixmap(self.left.pixmap().scaled(self.left.size(), QtCore.Qt.KeepAspectRatio, QtCore.Qt.SmoothTransformation))
        if self.right.pixmap():
            self.right.setPixmap(self.right.pixmap().scaled(self.right.size(), QtCore.Qt.KeepAspectRatio, QtCore.Qt.SmoothTransformation))

class MainWindow(QtWidgets.QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Batch Image Studio")
        self.resize(1280, 780)
        self.settings = load_settings()
        self.ext_presets = load_external_presets(ASSETS_DIR)
        self.all_presets = {**PRESETS, **self.ext_presets}
        self.qss_themes = load_qss_themes(ASSETS_DIR)

        # Menu
        menubar = self.menuBar()
        file_menu = menubar.addMenu("&File")
        tools_menu = menubar.addMenu("&Tools")
        view_menu = menubar.addMenu("&View")
        help_menu = menubar.addMenu("&Help")
        self.action_update = help_menu.addAction("Check for &Updates...")
        self.action_update.triggered.connect(self.check_updates)
        self.action_reload = file_menu.addAction("&Reload Presets/Themes")
        self.action_reload.triggered.connect(self.reload_assets)
        self.action_preset_editor = tools_menu.addAction("Preset &Editor...")
        self.action_accounts = tools_menu.addAction("Delivery &Accounts...")
        self.action_clients = tools_menu.addAction("Client &Address Book...")
        self.action_clients.triggered.connect(self.open_clients)
        self.action_jobs = tools_menu.addAction("&Proof Jobs...")
        self.action_jobs.triggered.connect(self.open_jobs)
        self.action_accounts.triggered.connect(self.open_accounts)
        self.action_preset_editor.triggered.connect(self.open_preset_editor)

        self.action_brand_logo = tools_menu.addAction("&Set App Logo (Pro)...")
        self.action_brand_logo.triggered.connect(self.set_brand_logo)

        self.action_quit = file_menu.addAction("E&xit")
        self.action_quit.triggered.connect(self.close)

        # Top header: brand logo + trial banner + theme chooser
        top = QtWidgets.QWidget(); top.setLayout(QtWidgets.QHBoxLayout())
        self.logo_label = QtWidgets.QLabel()
        self.logo_label.setFixedHeight(40)
        self.logo_label.setPixmap(QtGui.QPixmap(str(ASSETS_DIR / "branding" / "logo.png")).scaledToHeight(40, QtCore.Qt.SmoothTransformation) if (ASSETS_DIR / "branding" / "logo.png").exists() else QtGui.QPixmap())
        top.layout().addWidget(self.logo_label)

        self.banner = QtWidgets.QWidget()
        self.banner.setLayout(QtWidgets.QHBoxLayout())
        self.banner_label = QtWidgets.QLabel()
        self.license_btn = QtWidgets.QPushButton("Enter License...")
        self.banner.layout().addWidget(self.banner_label)
        self.banner.layout().addWidget(self.license_btn, 0, QtCore.Qt.AlignRight)
        self.license_btn.clicked.connect(self.enter_license)

        top.layout().addWidget(self.banner, 1)

        # Theme chooser
        self.theme_combo = QtWidgets.QComboBox()
        self.theme_combo.addItem("Dark", userData=("builtin","dark"))
        self.theme_combo.addItem("Light", userData=("builtin","light"))
        for qss in self.qss_themes:
            self.theme_combo.addItem(qss.stem, userData=("qss", str(qss)))
        # restore last
        last_theme = self.settings.get("theme", "dark")
        # If last is a qss path, select it
        found_index = 0
        for i in range(self.theme_combo.count()):
            kind, val = self.theme_combo.itemData(i)
            if (kind == "builtin" and val == last_theme) or (kind == "qss" and val == last_theme):
                found_index = i
                break
        self.theme_combo.setCurrentIndex(found_index)
        self.theme_combo.currentIndexChanged.connect(self.apply_theme)
        top.layout().addWidget(QtWidgets.QLabel("Theme:"))
        top.layout().addWidget(self.theme_combo)

        container = QtWidgets.QWidget()
        container.setLayout(QtWidgets.QVBoxLayout())
        container.layout().addWidget(top)

        # Source/dest selectors
        self.src_edit = QtWidgets.QLineEdit(self.settings.get("src_dir",""))
        self.dst_edit = QtWidgets.QLineEdit(self.settings.get("dst_dir",""))
        self.src_btn = QtWidgets.QPushButton("Browse...")
        self.dst_btn = QtWidgets.QPushButton("Browse...")
        self.src_btn.clicked.connect(lambda: self.pick_dir(self.src_edit))
        self.dst_btn.clicked.connect(lambda: self.pick_dir(self.dst_edit))

        sd = QtWidgets.QWidget()
        sd.setLayout(QtWidgets.QGridLayout())
        sd.layout().addWidget(QtWidgets.QLabel("Source folder:"), 0, 0)
        sd.layout().addWidget(self.src_edit, 0, 1)
        sd.layout().addWidget(self.src_btn, 0, 2)
        sd.layout().addWidget(QtWidgets.QLabel("Destination folder:"), 1, 0)
        sd.layout().addWidget(self.dst_edit, 1, 1)
        sd.layout().addWidget(self.dst_btn, 1, 2)

        # Presets & custom sizing
        self.preset_combo = QtWidgets.QComboBox()
        self.preset_combo.addItem("— Choose preset —", userData=None)
        self.populate_presets()
        self.mode_combo = QtWidgets.QComboBox()
        self.mode_combo.addItems(["Max side", "Exact size"])
        self.max_side_spin = QtWidgets.QSpinBox(); self.max_side_spin.setRange(64, 20000); self.max_side_spin.setValue(2000)
        self.exact_w = QtWidgets.QSpinBox(); self.exact_w.setRange(16, 20000); self.exact_w.setValue(1200)
        self.exact_h = QtWidgets.QSpinBox(); self.exact_h.setRange(16, 20000); self.exact_h.setValue(1200)

        # Watermark controls
        self.use_wm = QtWidgets.QCheckBox("Apply watermark")
        self.wm_combo = QtWidgets.QComboBox()
        self.refresh_watermarks()
        self.wm_opacity = QtWidgets.QDoubleSpinBox(); self.wm_opacity.setRange(0.05, 1.0); self.wm_opacity.setSingleStep(0.05); self.wm_opacity.setValue(0.25)
        self.wm_scale = QtWidgets.QDoubleSpinBox(); self.wm_scale.setRange(0.05, 1.0); self.wm_scale.setSingleStep(0.05); self.wm_scale.setValue(0.25)
        self.wm_pos = QtWidgets.QComboBox(); self.wm_pos.addItems(["Auto","Top-Left","Top-Right","Bottom-Left","Bottom-Right"])
        self.open_wm_folder = QtWidgets.QPushButton("Open watermark folder")
        self.open_wm_folder.clicked.connect(lambda: QtGui.QDesktopServices.openUrl(QtCore.QUrl.fromLocalFile(str(WATERMARKS_DIR))))

        # Format controls
        self.format_combo = QtWidgets.QComboBox(); self.format_combo.addItems([".jpg",".png",".webp"])
        self.quality = QtWidgets.QSlider(QtCore.Qt.Horizontal); self.quality.setRange(50, 100); self.quality.setValue(90)
        self.keep_meta = QtWidgets.QCheckBox("Keep metadata (EXIF)"); self.keep_meta.setChecked(True)

        # Max file size limiter & safety net
        self.limit_size_chk = QtWidgets.QCheckBox("Limit file size")
        self.max_size_mb = QtWidgets.QDoubleSpinBox(); self.max_size_mb.setRange(0.1, 999.0); self.max_size_mb.setDecimals(1); self.max_size_mb.setValue(20.0); self.max_size_mb.setSuffix(" MB")
        self.cap_dims_chk = QtWidgets.QCheckBox("Cap max dimensions")
        self.cap_w = QtWidgets.QSpinBox(); self.cap_w.setRange(16, 20000); self.cap_w.setValue(6000)
        self.cap_h = QtWidgets.QSpinBox(); self.cap_h.setRange(16, 20000); self.cap_h.setValue(6000)

        # Limiter badge
        self.limiter_badge = QtWidgets.QLabel("Limiter applied")
        self.limiter_badge.setStyleSheet("QLabel { background-color: #733; color: white; padding: 4px 8px; border-radius: 6px; }")
        self.limiter_badge.setVisible(False)

        # File list & actions
        self.list_view = QtWidgets.QListView()
        self.model = ImageListModel([])
        self.list_view.setModel(self.model)
        self.scan_btn = QtWidgets.QPushButton("Scan folder")
        self.process_btn = QtWidgets.QPushButton("Process Selected")
        self.process_all_btn = QtWidgets.QPushButton("Process All")
        self.compare_btn = QtWidgets.QPushButton("Compare")
        self.deliver_btn = QtWidgets.QPushButton("Deliver...")
        self.scan_btn.clicked.connect(self.scan_folder)
        self.process_btn.clicked.connect(lambda: self.process(selection_only=True))
        self.process_all_btn.clicked.connect(lambda: self.process(selection_only=False))
        self.compare_btn.clicked.connect(self.compare_selected)
        self.deliver_btn.clicked.connect(self.deliver_selected)

        # Options layout
        opts = QtWidgets.QGroupBox("Options")
        grid = QtWidgets.QGridLayout()
        r = 0
        grid.addWidget(QtWidgets.QLabel("Preset:"), r, 0); grid.addWidget(self.preset_combo, r, 1, 1, 3); r+=1
        grid.addWidget(QtWidgets.QLabel("Resize mode:"), r, 0); grid.addWidget(self.mode_combo, r, 1); grid.addWidget(QtWidgets.QLabel("Max side:"), r, 2); grid.addWidget(self.max_side_spin, r, 3); r+=1
        grid.addWidget(QtWidgets.QLabel("Exact size:"), r, 0); grid.addWidget(self.exact_w, r, 1); grid.addWidget(self.exact_h, r, 2); r+=1
        grid.addWidget(QtWidgets.QLabel("Output format:"), r, 0); grid.addWidget(self.format_combo, r, 1); grid.addWidget(QtWidgets.QLabel("Quality:"), r, 2); grid.addWidget(self.quality, r, 3); r+=1
        grid.addWidget(self.keep_meta, r, 1, 1, 3); r+=1
        grid.addWidget(self.limit_size_chk, r, 0); grid.addWidget(self.max_size_mb, r, 1)
        grid.addWidget(self.cap_dims_chk, r, 2); grid.addWidget(self.cap_w, r, 3); r+=1
        grid.addWidget(QtWidgets.QLabel("Max H:"), r, 2); grid.addWidget(self.cap_h, r, 3); r+=1

        wm_box = QtWidgets.QGroupBox("Watermark")
        wm_grid = QtWidgets.QGridLayout()
        wm_grid.addWidget(self.use_wm, 0, 0)
        wm_grid.addWidget(QtWidgets.QLabel("File:"), 1, 0); wm_grid.addWidget(self.wm_combo, 1, 1, 1, 3)
        wm_grid.addWidget(QtWidgets.QLabel("Opacity:"), 2, 0); wm_grid.addWidget(self.wm_opacity, 2, 1)
        wm_grid.addWidget(QtWidgets.QLabel("Scale:"), 2, 2); wm_grid.addWidget(self.wm_scale, 2, 3)
        wm_grid.addWidget(QtWidgets.QLabel("Position:"), 3, 0); wm_grid.addWidget(self.wm_pos, 3, 1)
        wm_grid.addWidget(self.open_wm_folder, 3, 2, 1, 2)
        wm_box.setLayout(wm_grid)

        # Pack
        left = QtWidgets.QWidget(); left.setLayout(QtWidgets.QVBoxLayout())
        left.layout().addWidget(sd)
        left.layout().addWidget(opts)
        left.layout().addWidget(wm_box)
        left.layout().addWidget(self.limiter_badge, 0, QtCore.Qt.AlignLeft)
        left.layout().addWidget(self.scan_btn)
        left.layout().addWidget(self.process_btn)
        left.layout().addWidget(self.process_all_btn)
        left.layout().addWidget(self.compare_btn)
        left.layout().addWidget(self.deliver_btn)

        splitter = QtWidgets.QSplitter()
        left_scroll = QtWidgets.QScrollArea(); left_scroll.setWidgetResizable(True); left_scroll.setWidget(left)
        right_panel = QtWidgets.QWidget(); right_panel.setLayout(QtWidgets.QVBoxLayout())
        right_panel.layout().addWidget(QtWidgets.QLabel("Files"))
        right_panel.layout().addWidget(self.list_view, 1)
        right_panel.layout().addWidget(QtWidgets.QLabel("Preview"))
        right_panel.layout().addWidget(self.preview_widget(), 2)

        splitter.addWidget(left_scroll)
        splitter.addWidget(right_panel)
        splitter.setStretchFactor(1, 1)

        container.layout().addWidget(splitter, 1)
        self.setCentralWidget(container)

        self.preset_combo.currentIndexChanged.connect(self.apply_preset)
        self.update_banner()
        self.apply_theme()

        # Enable/disable pro branding
        self.update_branding_availability()

    def preview_widget(self):
        self.preview = PreviewWidget()
        return self.preview

    def update_branding_availability(self):
        self.action_brand_logo.setEnabled(is_pro())

    def populate_presets(self):
        self.preset_combo.clear()
        self.preset_combo.addItem("— Choose preset —", userData=None)
        for k in sorted(self.all_presets.keys()):
            self.preset_combo.addItem(k, userData=k)

    def reload_assets(self):
        self.ext_presets = load_external_presets(ASSETS_DIR)
        self.all_presets = {**PRESETS, **self.ext_presets}
        self.qss_themes = load_qss_themes(ASSETS_DIR)
        # repopulate themes
        self.theme_combo.clear()
        self.theme_combo.addItem("Dark", userData=("builtin","dark"))
        self.theme_combo.addItem("Light", userData=("builtin","light"))
        for qss in self.qss_themes:
            self.theme_combo.addItem(qss.stem, userData=("qss", str(qss)))
        self.populate_presets()
        QtWidgets.QMessageBox.information(self, "Reloaded", "Presets/themes reloaded.")

    def apply_theme(self):
        kind, val = self.theme_combo.currentData()
        if kind == "builtin":
            qdarktheme.setup_theme(val)
            QtWidgets.QApplication.instance().setStyleSheet("")
            self.settings["theme"] = val
        else:
            # QSS theme
            qdarktheme.setup_theme("dark")
            try:
                css = Path(val).read_text(encoding="utf-8")
                QtWidgets.QApplication.instance().setStyleSheet(css)
                self.settings["theme"] = val
            except Exception as e:
                QtWidgets.QMessageBox.warning(self, "Theme", f"Failed to load theme: {e}")
        save_settings(self.settings)

    def check_updates(self):
        url = self.settings.get("manifest_url", "https://aidatametrix.com/batch-image-studio/manifest.json")
        ok, msg = check_for_updates(url, ASSETS_DIR)
        QtWidgets.QMessageBox.information(self, "Updates", msg)

    def update_banner(self):
        st = get_trial_status()
        if st["expired"]:
            self.banner_label.setText("Trial expired. Enter a license to continue processing.")
        else:
            self.banner_label.setText(f"Trial: {st['remaining_days']} day(s) remaining.")
        self.banner.setVisible(st["expired"] or st["remaining_days"] <= 3)

    def enter_license(self):
        key, ok = QtWidgets.QInputDialog.getText(self, "Enter License", "License key:")
        if ok and key:
            if apply_license(key):
                QtWidgets.QMessageBox.information(self, "License", "Thank you! License applied.")
                self.update_banner()
                self.update_branding_availability()
            else:
                QtWidgets.QMessageBox.warning(self, "License", "Invalid key.")

    def set_brand_logo(self):
        if not is_pro():
            QtWidgets.QMessageBox.information(self, "Branding", "Branding is available in Pro.")
            return
        file, _ = QtWidgets.QFileDialog.getOpenFileName(self, "Choose logo image", str(Path.home()), "Images (*.png *.jpg *.jpeg *.webp)")
        if file:
            dest = ASSETS_DIR / "branding" / "logo.png"
            dest.parent.mkdir(parents=True, exist_ok=True)
            try:
                # Normalize to PNG
                from PIL import Image
                im = Image.open(file).convert("RGBA")
                im.save(dest)
                self.logo_label.setPixmap(QtGui.QPixmap(str(dest)).scaledToHeight(40, QtCore.Qt.SmoothTransformation))
                QtWidgets.QMessageBox.information(self, "Branding", "Logo updated.")
            except Exception as e:
                QtWidgets.QMessageBox.warning(self, "Branding", f"Failed to set logo: {e}")

    def pick_dir(self, line: QtWidgets.QLineEdit):
        d = QtWidgets.QFileDialog.getExistingDirectory(self, "Choose folder", str(Path.home()))
        if d:
            line.setText(d)

    def refresh_watermarks(self):
        WATERMARKS_DIR.mkdir(parents=True, exist_ok=True)
        self.wm_combo.clear()
        self.wm_combo.addItem("— None —", userData=None)
        pngs = sorted(WATERMARKS_DIR.glob("*.png"))
        for p in pngs:
            self.wm_combo.addItem(p.name, userData=str(p))

    def scan_folder(self):
        src = Path(self.src_edit.text())
        if not src.exists():
            QtWidgets.QMessageBox.warning(self, "Source", "Source folder not found.")
            return
        imgs = [p for p in src.iterdir() if p.suffix.lower() in SUPPORTED_FORMATS]
        self.model.setDataSet(imgs)
        if not imgs:
            QtWidgets.QMessageBox.information(self, "Scan", "No supported images found.")

    def open_preset_editor(self):
        dlg = PresetEditor(ASSETS_DIR, self.ext_presets)
        if dlg.exec():
            # After saving, reload assets to pick up changes
            self.reload_assets()

    def apply_preset(self):
        key = self.preset_combo.currentData()
        if not key:
            return
        p = self.all_presets[key]
        if p["mode"] == "max_side":
            self.mode_combo.setCurrentIndex(0)
            self.max_side_spin.setValue(p["size"])
        else:
            self.mode_combo.setCurrentIndex(1)
            self.exact_w.setValue(p["width"])
            self.exact_h.setValue(p["height"])
        if p.get("max_mb") is not None:
            self.limit_size_chk.setChecked(True)
            self.max_size_mb.setValue(float(p["max_mb"]))
        if p.get("max_w") or p.get("max_h"):
            self.cap_dims_chk.setChecked(True)
            if p.get("max_w"): self.cap_w.setValue(int(p["max_w"]))
            if p.get("max_h"): self.cap_h.setValue(int(p["max_h"]))

    def collect_options(self):
        preset_key = self.preset_combo.currentData()
        resize_mode = "max_side" if self.mode_combo.currentIndex() == 0 else "exact"
        max_side = self.max_side_spin.value()
        exact_w = self.exact_w.value()
        exact_h = self.exact_h.value()
        if preset_key:
            p = self.all_presets[preset_key]
            if p["mode"] == "max_side":
                resize_mode = "max_side"; max_side = p["size"]
            else:
                resize_mode = "exact"; exact_w = p["width"]; exact_h = p["height"]
        fmt = self.format_combo.currentText()
        wm_path = Path(self.wm_combo.currentData()) if (self.use_wm.isChecked() and self.wm_combo.currentData()) else None
        wm_pos_map = {"Auto":"auto","Top-Left":"top-left","Top-Right":"top-right","Bottom-Left":"bottom-left","Bottom-Right":"bottom-right"}
        max_bytes = None
        if self.limit_size_chk.isChecked():
            max_bytes = int(self.max_size_mb.value() * 1024 * 1024)
        cap_w = self.cap_w.value() if self.cap_dims_chk.isChecked() else None
        cap_h = self.cap_h.value() if self.cap_dims_chk.isChecked() else None
        return dict(
            resize_mode=resize_mode,
            max_side=max_side,
            exact_w=exact_w,
            exact_h=exact_h,
            fmt_ext=fmt,
            quality=self.quality.value(),
            keep_metadata=self.keep_meta.isChecked(),
            watermark_path=wm_path,
            watermark_opacity=self.wm_opacity.value(),
            watermark_scale=self.wm_scale.value(),
            watermark_position=wm_pos_map[self.wm_pos.currentText()],
            max_filesize_bytes=max_bytes,
            cap_max_w=cap_w,
            cap_max_h=cap_h,
        )

    def process(self, selection_only: bool):
        st = get_trial_status()
        if st["expired"]:
            QtWidgets.QMessageBox.warning(self, "Trial", "Your trial has expired. Enter a license to continue.")
            return

        src = Path(self.src_edit.text()); dst = Path(self.dst_edit.text())
        if not src.exists() or not dst.exists():
            QtWidgets.QMessageBox.warning(self, "Folders", "Please choose valid source and destination folders.")
            return

        opts = self.collect_options()
        rows = [idx.row() for idx in self.list_view.selectedIndexes()] if selection_only else list(range(self.model.rowCount()))
        if not rows:
            QtWidgets.QMessageBox.information(self, "Process", "No files selected.")
            return

        csv_rows = []
        limiter_triggered = False
        progress = QtWidgets.QProgressDialog("Processing images...", "Cancel", 0, len(rows), self)
        progress.setWindowModality(QtCore.Qt.WindowModal)
        for i, r in enumerate(rows, start=1):
            if progress.wasCanceled(): break
            p = self.model.get(r)
            rel = p.relative_to(Path(self.src_edit.text()))
            out_path = Path(self.dst_edit.text()) / rel
            try:
                info = process_image(p, out_path, **opts)
                csv_rows.append(info)
                if info.get("limited_by_filesize") or info.get("was_capped_by_max_dim"):
                    limiter_triggered = True
            except Exception as e:
                csv_rows.append({"input_name": p.name, "notes": f"ERROR: {e}"})
            progress.setValue(i)
        progress.close()

        # CSV export
        if csv_rows:
            stamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
            report = Path(self.dst_edit.text()) / f"batch_report_{stamp}.csv"
            with open(report, "w", newline="", encoding="utf-8") as f:
                w = csv.DictWriter(f, fieldnames=[
                    "input_name","output_name","orig_w","orig_h","final_w","final_h",
                    "format","quality_used","limited_by_filesize","downscale_steps",
                    "was_capped_by_max_dim","bytes_before","bytes_after","notes"
                ])
                w.writeheader()
                for row in csv_rows:
                    w.writerow(row)

        self.limiter_badge.setVisible(limiter_triggered)
        QtWidgets.QMessageBox.information(self, "Done", f"Processing complete. Report saved to:\n{report}")

    
    def deliver_selected(self):
        # Candidate files = processed outputs in destination that match selected names (or all if none selected)
        dst = Path(self.dst_edit.text())
        if not dst.exists():
            QtWidgets.QMessageBox.warning(self, "Deliver", "Please choose a valid destination folder first and process images.")
            return
        rows = [idx.row() for idx in self.list_view.selectedIndexes()]
        names = [self.model.get(r).name for r in rows] if rows else [p.name for p in self.model.paths]
        # Find outputs in dst by basename (any extension)
        candidates = []
        for n in names:
            stem = Path(n).stem
            for p in dst.glob(f"{stem}.*"):
                if p.is_file():
                    candidates.append(p)
        if not candidates:
            QtWidgets.QMessageBox.information(self, "Deliver", "No processed files found in destination. Process first.")
            return

        from .accounts import load_accounts
        acc = load_accounts(); s3_exp = int(((acc.get("s3") or {}).get("expires_sec")) or 7*24*3600)
        dlg = DeliverDialog(candidates, dst, clients=load_clients(), s3_expiry_default=s3_exp)
        if dlg.exec():
            sel = dlg.get_selection()
            if not sel["paths"]:
                QtWidgets.QMessageBox.information(self, "Deliver", "No files selected.")
                return
            # Create a named ZIP
            stamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
            zip_name = f"images_{stamp}.zip"
            link = None
            try:
                method = sel["method"]
                if method == "Local ZIP only":
                    zp = local_zip(sel["paths"], sel["out_dir"], zip_name)
                    QtWidgets.QMessageBox.information(self, "Delivered", f"ZIP created:\n{zp}")
                    QtGui.QDesktopServices.openUrl(QtCore.QUrl.fromLocalFile(str(zp.parent)))
                elif method == "Upload via transfer.sh (temp link)":
                    zp = local_zip(sel["paths"], sel["out_dir"], zip_name)
                    ok, link = transfer_sh(zp)
                    if ok:
                        QtWidgets.QApplication.clipboard().setText(link)
                        QtWidgets.QMessageBox.information(self, "Delivered", f"Link copied to clipboard:\n{link}")
                    else:
                        QtWidgets.QMessageBox.warning(self, "Deliver", f"Upload failed: {link}")
                        return
                elif method == "Upload via file.io (temp link)":
                    zp = local_zip(sel["paths"], sel["out_dir"], zip_name)
                    ok, link = file_io(zp)
                    if ok:
                        QtWidgets.QApplication.clipboard().setText(link)
                        QtWidgets.QMessageBox.information(self, "Delivered", f"Link copied to clipboard:\n{link}")
                    else:
                        QtWidgets.QMessageBox.warning(self, "Deliver", f"Upload failed: {link}")
                        return
                elif method == "Upload to S3/R2 (presigned link)":
                    # Requires S3 config
                    acc = load_accounts().get("s3")
                    if not acc:
                        QtWidgets.QMessageBox.warning(self, "S3/R2", "Configure S3/R2 in Tools → Delivery Accounts...")
                        return
                    zp = local_zip(sel["paths"], sel["out_dir"], zip_name)
                    ok, link = s3_presign_and_upload(zp,
                        access_key=acc["access_key"], secret_key=acc["secret_key"],
                        bucket=acc["bucket"], key_prefix=acc.get("name","uploads"),
                        region=acc.get("region","auto"), endpoint_url=acc.get("endpoint_url"))
                    if ok:
                        QtWidgets.QApplication.clipboard().setText(link)
                        QtWidgets.QMessageBox.information(self, "Delivered", f"Presigned link copied to clipboard:\n{link}")
                    else:
                        QtWidgets.QMessageBox.warning(self, "S3/R2", f"Failed: {link}")
                        return
                elif method == "Upload to Google Drive (share link)":
                    if not have_google_drive():
                        QtWidgets.QMessageBox.warning(self, "Google Drive", "Connect Google Drive in Tools → Delivery Accounts...")
                        return
                    zp = local_zip(sel["paths"], sel["out_dir"], zip_name)
                    ok, link = gdrive_upload_zip(zp, get_google_token_path())
                    if ok:
                        QtWidgets.QApplication.clipboard().setText(link)
                        QtWidgets.QMessageBox.information(self, "Delivered", f"Link copied to clipboard:\n{link}")
                    else:
                        QtWidgets.QMessageBox.warning(self, "Google Drive", f"Failed: {link}")
                        return
                elif method == "Upload to Dropbox (share link)":
                    acc = load_accounts().get("dropbox", {})
                    if not acc.get("access_token"):
                        QtWidgets.QMessageBox.warning(self, "Dropbox", "Connect Dropbox in Tools → Delivery Accounts...")
                        return
                    zp = local_zip(sel["paths"], sel["out_dir"], zip_name)
                    ok, link = dropbox_upload_zip(zp, acc["access_token"])
                    if ok:
                        QtWidgets.QApplication.clipboard().setText(link)
                        QtWidgets.QMessageBox.information(self, "Delivered", f"Link copied to clipboard:\n{link}")
                    else:
                        QtWidgets.QMessageBox.warning(self, "Dropbox", f"Failed: {link}")
                        return
                elif method == "Upload to OneDrive (share link)":
                    acc = load_accounts().get("onedrive", {})
                    if not acc.get("access_token"):
                        QtWidgets.QMessageBox.warning(self, "OneDrive", "Connect OneDrive in Tools → Delivery Accounts...")
                        return
                    zp = local_zip(sel["paths"], sel["out_dir"], zip_name)
                    ok, link = onedrive_upload_zip(zp, acc["access_token"])
                    if ok:
                        QtWidgets.QApplication.clipboard().setText(link)
                        QtWidgets.QMessageBox.information(self, "Delivered", f"Link copied to clipboard:\n{link}")
                    else:
                        QtWidgets.QMessageBox.warning(self, "OneDrive", f"Failed: {link}")
                        return
                else:
                    # Save zip to a sync folder
                    zp = local_zip(sel["paths"], sel["sync_dir"], zip_name)
                    QtWidgets.QMessageBox.information(self, "Delivered", f"ZIP saved to sync folder:\n{zp}")
                    QtGui.QDesktopServices.openUrl(QtCore.QUrl.fromLocalFile(str(zp.parent)))

                # Optionally open default mail client with mailto:
                if link and sel["recipient"]:
                    from urllib.parse import quote
                    mailto = f"mailto:{sel['recipient']}?subject={quote(sel['subject'])}&body={quote(sel['message'].replace('{link}', link))}"
                    QtGui.QDesktopServices.openUrl(QtCore.QUrl(mailto))
            except Exception as e:
                QtWidgets.QMessageBox.warning(self, "Deliver", f"Failed: {e}")

    def open_accounts(self):
        dlg = AccountsDialog(ASSETS_DIR)
        dlg.exec()

    def open_clients(self):
        dlg = ClientsDialog(ASSETS_DIR)
        dlg.exec()

    def open_jobs(self):
        dlg = JobsDialog(Path(self.dst_edit.text() or ASSETS_DIR))
        dlg.exec()

        dlg = AccountsDialog(ASSETS_DIR)
        dlg.exec()

    def compare_selected(self):
        idxs = self.list_view.selectedIndexes()
        if not idxs: return
        p = self.model.get(idxs[0].row())
        left = QtGui.QPixmap(str(p))
        tmp = Path(tempfile.gettempdir()) / (p.stem + "_preview" + p.suffix)
        opts = self.collect_options()
        try:
            info = process_image(p, tmp, **opts)
            right = QtGui.QPixmap(str(tmp))
            self.limiter_badge.setVisible(info.get("limited_by_filesize") or info.get("was_capped_by_max_dim"))
            self.preview.set_pixmaps(left, right)
        except Exception as e:
            QtWidgets.QMessageBox.warning(self, "Preview", f"Failed to create preview: {e}")

    def closeEvent(self, e):
        current_kind, current_val = self.theme_combo.currentData()
        self.settings.update({
            "src_dir": self.src_edit.text(),
            "dst_dir": self.dst_edit.text(),
            "theme": current_val if current_kind=="builtin" else current_val
        })
        save_settings(self.settings)
        super().closeEvent(e)

def main():
    app = QtWidgets.QApplication(sys.argv)
    w = MainWindow()
    w.show()
    sys.exit(app.exec())

if __name__ == "__main__":
    main()
