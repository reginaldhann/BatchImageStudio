import json
from pathlib import Path
from appdirs import user_config_dir

APP_NAME = "BatchImageStudio"
COMPANY = "YourCompany"

def _config_path() -> Path:
    base = Path(user_config_dir(APP_NAME, COMPANY))
    base.mkdir(parents=True, exist_ok=True)
    return base / "settings.json"

def load_settings():
    p = _config_path()
    if p.exists():
        try:
            return json.loads(p.read_text(encoding="utf-8"))
        except Exception:
            return {}
    return {}

def save_settings(data: dict):
    p = _config_path()
    p.write_text(json.dumps(data, indent=2), encoding="utf-8")
