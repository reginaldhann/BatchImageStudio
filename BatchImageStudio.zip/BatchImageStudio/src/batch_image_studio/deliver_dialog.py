# src/batch_image_studio/deliver_dialog.py
from PySide6 import QtWidgets, QtCore
from pathlib import Path

class DeliverDialog(QtWidgets.QDialog):
    def __init__(self, candidates: list[Path], default_out_dir: Path, *, clients: list[dict] = None, s3_expiry_default: int = 604800):
        super().__init__()
        self.setWindowTitle("Deliver to Client")
        self.resize(520, 360)
        self.candidates = candidates
        self.clients = clients or []
        self.s3_expiry_default = s3_expiry_default
        self.selected = set(range(len(candidates)))
        self.default_out_dir = default_out_dir

        layout = QtWidgets.QVBoxLayout(self)


        # Client row
        self.client_combo = QtWidgets.QComboBox()
        self.client_combo.addItem("— No client —", userData=None)
        for c in self.clients:
            self.client_combo.addItem(f"{c.get('name','')} <{c.get('email','')}>", userData=c)
        self.client_thumb = QtWidgets.QLabel(); self.client_thumb.setFixedSize(48,48); self.client_thumb.setStyleSheet("border:1px solid #444;")

        # Proof workflow
        self.proof_chk = QtWidgets.QCheckBox("Proof workflow (send watermarked proofs now; finals later)")
        self.proof_note = QtWidgets.QLabel("Tip: choose a watermark above first. Finals are sent via Jobs after approval.")

        # S3 expiry
        self.s3_expiry = QtWidgets.QSpinBox(); self.s3_expiry.setRange(3600, 30*24*3600); self.s3_expiry.setValue(s3_expiry_default)

        # Connect client selection → thumbnail
        self.client_combo.currentIndexChanged.connect(self.update_client_thumb)

        # File checklist
        self.list = QtWidgets.QListWidget()
        for p in candidates:
            item = QtWidgets.QListWidgetItem(p.name)
            item.setCheckState(QtCore.Qt.Checked)
            self.list.addItem(item)
        layout.addWidget(QtWidgets.QLabel("Select files to include:"))
        layout.addWidget(self.list, 1)

        # Method
        self.method = QtWidgets.QComboBox()
        self.method.addItems(["Local ZIP only", "Upload via transfer.sh (temp link)", "Upload via file.io (temp link)", "Save to sync folder (Dropbox/Drive/OneDrive)"])

        self.out_dir_edit = QtWidgets.QLineEdit(str(default_out_dir))
        self.out_dir_btn = QtWidgets.QPushButton("Browse...")
        self.out_dir_btn.clicked.connect(self.choose_dir)

        self.sync_dir_edit = QtWidgets.QLineEdit(str(default_out_dir))
        self.sync_dir_btn = QtWidgets.QPushButton("Browse...")
        self.sync_dir_btn.clicked.connect(self.choose_sync_dir)

        grid = QtWidgets.QGridLayout()
        r=0
        grid.addWidget(QtWidgets.QLabel("Client:"), r, 0)
        grid.addWidget(self.client_combo, r, 1)
        grid.addWidget(self.client_thumb, r, 2); r+=1
        grid.addWidget(QtWidgets.QLabel("Method:"), r, 0)
        grid.addWidget(self.method, r, 1, 1, 2); r+=1
        grid.addWidget(QtWidgets.QLabel("S3/R2 Expiry (sec):"), r, 0)
        grid.addWidget(self.s3_expiry, r, 1); r+=1
        grid.addWidget(QtWidgets.QLabel("ZIP output folder:"), r, 0)
        grid.addWidget(self.out_dir_edit, r, 1)
        grid.addWidget(self.out_dir_btn, r, 2); r+=1
        grid.addWidget(QtWidgets.QLabel("Sync folder (if chosen):"), r, 0)
        grid.addWidget(self.sync_dir_edit, r, 1)
        grid.addWidget(self.sync_dir_btn, r, 2); r+=1
        layout.addLayout(grid)

        # Proof workflow
        layout.addWidget(self.proof_chk)
        layout.addWidget(self.proof_note)

        # Email compose
        self.recipient = QtWidgets.QLineEdit()
        self.subject = QtWidgets.QLineEdit("Your image delivery")
        self.message = QtWidgets.QPlainTextEdit("Hi,\n\nHere are your images. Download link: {link}\n\nBest,\n")
        mail_grid = QtWidgets.QGridLayout()
        r=0
        mail_grid.addWidget(QtWidgets.QLabel("Recipient email (optional):"), r, 0)
        mail_grid.addWidget(self.recipient, r, 1, 1, 2); r+=1
        mail_grid.addWidget(QtWidgets.QLabel("Subject:"), r, 0)
        mail_grid.addWidget(self.subject, r, 1, 1, 2); r+=1
        mail_grid.addWidget(QtWidgets.QLabel("Message:"), r, 0, QtCore.Qt.AlignTop)
        mail_grid.addWidget(self.message, r, 1, 1, 2); r+=1
        layout.addLayout(mail_grid)

        # Buttons
        btns = QtWidgets.QDialogButtonBox(QtWidgets.QDialogButtonBox.Ok | QtWidgets.QDialogButtonBox.Cancel)
        btns.accepted.connect(self.accept)
        btns.rejected.connect(self.reject)
        layout.addWidget(btns)

    def choose_dir(self):
        d = QtWidgets.QFileDialog.getExistingDirectory(self, "Choose output folder", self.out_dir_edit.text())
        if d: self.out_dir_edit.setText(d)

    def choose_sync_dir(self):
        d = QtWidgets.QFileDialog.getExistingDirectory(self, "Choose sync folder", self.sync_dir_edit.text())
        if d: self.sync_dir_edit.setText(d)

    def get_selection(self):
        paths = []
        for i in range(self.list.count()):
            item = self.list.item(i)
            if item.checkState() == QtCore.Qt.Checked:
                paths.append(self.candidates[i])
        return dict(
            method=self.method.currentText(),
            out_dir=Path(self.out_dir_edit.text()),
            sync_dir=Path(self.sync_dir_edit.text()),
            paths=paths,
            recipient=self.recipient.text().strip(),
            subject=self.subject.text().strip(),
            message=self.message.toPlainText(),
        )


    def update_client_thumb(self):
        c = self.client_combo.currentData()
        if c and c.get("thumbnail") and Path(c["thumbnail"]).exists():
            pm = QtGui.QPixmap(c["thumbnail"]).scaled(48,48, QtCore.Qt.KeepAspectRatio, QtCore.Qt.SmoothTransformation)
            self.client_thumb.setPixmap(pm)
        else:
            self.client_thumb.setPixmap(QtGui.QPixmap())

    def get_selection(self):
        paths = []
        for i in range(self.list.count()):
            item = self.list.item(i)
            if item.checkState() == QtCore.Qt.Checked:
                paths.append(self.candidates[i])
        return dict(
            method=self.method.currentText(),
            out_dir=Path(self.out_dir_edit.text()),
            sync_dir=Path(self.sync_dir_edit.text()),
            paths=paths,
            recipient=self.recipient.text().strip(),
            subject=self.subject.text().strip(),
            message=self.message.toPlainText(),
            client=self.client_combo.currentData(),
            s3_expiry=int(self.s3_expiry.value()),
            proof=self.proof_chk.isChecked(),
        )
