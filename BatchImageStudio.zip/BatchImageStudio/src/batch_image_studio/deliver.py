# src/batch_image_studio/deliver.py
"""
Delivery backends for sharing processed images with clients.

Methods:
- local_zip: create a .zip and return its local path
- transfer_sh: upload a .zip to https://transfer.sh and return a temporary link
- file_io: upload a .zip to https://file.io and return a temporary link
- save_to_sync: create a .zip under a user-selected sync folder (Dropbox/Drive/OneDrive)

Notes:
- transfer.sh and file.io links are temporary and subject to provider limits.
- For production, consider S3/R2 or Drive/Dropbox/OneDrive APIs with OAuth.
"""
from __future__ import annotations
from pathlib import Path
import tempfile, shutil, requests, json

def make_zip(paths: list[Path], zip_path: Path) -> Path:
    zip_path.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory() as td:
        # Build zip with relative names
        with shutil.make_archive(zip_path.with_suffix('').as_posix(), 'zip', root_dir=None) as _:
            pass
    # shutil.make_archive already wrote the zip; but we need content.
    # Let's implement manual zip to control names.
    import zipfile
    with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as z:
        for p in paths:
            arc = p.name
            z.write(p, arcname=arc)
    return zip_path

def local_zip(paths: list[Path], out_dir: Path, zip_name: str) -> Path:
    out_dir.mkdir(parents=True, exist_ok=True)
    zp = out_dir / zip_name
    return make_zip(paths, zp)

def transfer_sh(zip_path: Path) -> tuple[bool, str]:
    try:
        with open(zip_path, "rb") as f:
            # transfer.sh expects filename in URL; returns link in body
            url = f"https://transfer.sh/{zip_path.name}"
            r = requests.put(url, data=f)
            if r.ok:
                return True, r.text.strip()
            return False, f"Upload failed: {r.status_code}"
    except Exception as e:
        return False, str(e)

def file_io(zip_path: Path) -> tuple[bool, str]:
    try:
        with open(zip_path, "rb") as f:
            r = requests.post("https://file.io", files={"file": (zip_path.name, f)})
            if r.ok:
                data = r.json()
                if data.get("success") and data.get("link"):
                    return True, data["link"]
                return False, f"Response: {data}"
            return False, f"Upload failed: {r.status_code}"
    except Exception as e:
        return False, str(e)

def save_to_sync(paths: list[Path], sync_dir: Path, zip_name: str) -> Path:
    sync_dir.mkdir(parents=True, exist_ok=True)
    zp = sync_dir / zip_name
    return make_zip(paths, zp)


# --- Advanced backends ---
def s3_presign_and_upload(zip_path: Path, *, access_key: str, secret_key: str, bucket: str, key_prefix: str, region: str = "auto", endpoint_url: str | None = None, expires: int = 7*24*3600):
    """
    Uploads to S3-compatible storage (AWS S3 or Cloudflare R2) and returns a presigned URL.
    For R2, pass endpoint_url like: https://<accountid>.r2.cloudflarestorage.com
    """
    import boto3
    session = boto3.session.Session(aws_access_key_id=access_key, aws_secret_access_key=secret_key, region_name=None if region=="auto" else region)
    s3 = session.client("s3", endpoint_url=endpoint_url)
    key = f"{key_prefix.rstrip('/')}/{zip_path.name}"
    s3.upload_file(str(zip_path), bucket, key)
    url = s3.generate_presigned_url(
        ClientMethod="get_object",
        Params={"Bucket": bucket, "Key": key},
        ExpiresIn=expires,
    )
    return True, url

def gdrive_upload_zip(zip_path: Path, token_path: Path) -> tuple[bool, str]:
    try:
        from google.oauth2.credentials import Credentials
        from googleapiclient.discovery import build
        creds = Credentials.from_authorized_user_file(str(token_path), scopes=["https://www.googleapis.com/auth/drive.file"])
        service = build("drive", "v3", credentials=creds)
        file_metadata = {"name": zip_path.name}
        media = None
        from googleapiclient.http import MediaFileUpload
        media = MediaFileUpload(str(zip_path), mimetype="application/zip")
        f = service.files().create(body=file_metadata, media_body=media, fields="id, webViewLink, webContentLink").execute()
        # Create anyone-with-link
        service.permissions().create(fileId=f["id"], body={"type":"anyone","role":"reader"}).execute()
        # Prefer webContentLink (direct download) if present
        link = f.get("webContentLink") or f.get("webViewLink")
        return True, link
    except Exception as e:
        return False, str(e)

def dropbox_upload_zip(zip_path: Path, access_token: str) -> tuple[bool, str]:
    try:
        import dropbox
        dbx = dropbox.Dropbox(access_token)
        dest = f"/{zip_path.name}"
        with open(zip_path, "rb") as f:
            dbx.files_upload(f.read(), dest, mode=dropbox.files.WriteMode("overwrite"))
        # Create shared link
        link_meta = dbx.sharing_create_shared_link_with_settings(dest)
        return True, link_meta.url.replace("?dl=0","?dl=1")
    except Exception as e:
        return False, str(e)

def onedrive_upload_zip(zip_path: Path, access_token: str) -> tuple[bool, str]:
    try:
        import requests, json
        headers = {"Authorization": f"Bearer {access_token}"}
        # Upload to root (simple upload <4MB): use upload session for large files
        size = zip_path.stat().st_size
        if size <= 4*1024*1024:
            url = f"https://graph.microsoft.com/v1.0/me/drive/root:/{zip_path.name}:/content"
            with open(zip_path, "rb") as f:
                r = requests.put(url, headers=headers, data=f.read())
            r.raise_for_status()
            item = r.json()
        else:
            # Create upload session
            url = f"https://graph.microsoft.com/v1.0/me/drive/root:/{zip_path.name}:/createUploadSession"
            r = requests.post(url, headers=headers, json={})
            r.raise_for_status()
            up = r.json()
            upload_url = up["uploadUrl"]
            # Chunked upload (simple, 5MB chunks)
            chunk = 5*1024*1024
            with open(zip_path, "rb") as f:
                i = 0
                while True:
                    data = f.read(chunk)
                    if not data:
                        break
                    start = i
                    end = i + len(data) - 1
                    total = size
                    headers2 = {"Content-Length": str(len(data)), "Content-Range": f"bytes {start}-{end}/{total}"}
                    rr = requests.put(upload_url, headers=headers2, data=data)
                    rr.raise_for_status()
                    i = end + 1
            # Get item
            # Graph returns final item metadata in last response; we omit here for brevity.
        # Create anyone-with-link
        r = requests.post(f"https://graph.microsoft.com/v1.0/me/drive/root:/{zip_path.name}:/createLink",
                          headers=headers, json={"type":"view","scope":"anonymous"})
        r.raise_for_status()
        return True, r.json()["link"]["webUrl"]
    except Exception as e:
        return False, str(e)
