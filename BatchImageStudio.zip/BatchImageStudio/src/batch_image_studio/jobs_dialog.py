# src/batch_image_studio/jobs_dialog.py
from PySide6 import QtWidgets, QtGui, QtCore
from pathlib import Path
from .proof_jobs import load_jobs, save_jobs, mark_completed
from .deliver import local_zip, transfer_sh, file_io, s3_presign_and_upload, gdrive_upload_zip, dropbox_upload_zip, onedrive_upload_zip
from .accounts import load_accounts, get_google_token_path, have_google_drive
import datetime

class JobsDialog(QtWidgets.QDialog):
    def __init__(self, default_out_dir: Path):
        super().__init__()
        self.setWindowTitle("Proof Jobs")
        self.resize(780, 520)
        self.default_out_dir = default_out_dir

        self.model = QtGui.QStandardItemModel(0, 6)
        self.model.setHorizontalHeaderLabels(["ID","Client","Status","Method","Created","Notes"])
        self.table = QtWidgets.QTableView()
        self.table.setModel(self.model)
        self.table.setSelectionBehavior(QtWidgets.QAbstractItemView.SelectRows)
        self.table.setEditTriggers(QtWidgets.QAbstractItemView.NoEditTriggers)

        self.send_btn = QtWidgets.QPushButton("Send Finals")
        self.refresh_btn = QtWidgets.QPushButton("Refresh")
        self.close_btn = QtWidgets.QPushButton("Close")
        btns = QtWidgets.QHBoxLayout()
        btns.addWidget(self.send_btn); btns.addStretch(1); btns.addWidget(self.refresh_btn); btns.addWidget(self.close_btn)

        layout = QtWidgets.QVBoxLayout(self)
        layout.addWidget(self.table, 1)
        layout.addLayout(btns)

        self.refresh()
        self.refresh_btn.clicked.connect(self.refresh)
        self.send_btn.clicked.connect(self.send_finals)
        self.close_btn.clicked.connect(self.accept)

    def refresh(self):
        self.model.removeRows(0, self.model.rowCount())
        for j in load_jobs():
            row = [
                QtGui.QStandardItem(j.get("id","")),
                QtGui.QStandardItem(j.get("client_email","")),
                QtGui.QStandardItem(j.get("status","pending")),
                QtGui.QStandardItem(j.get("method","")),
                QtGui.QStandardItem(j.get("created","")),
                QtGui.QStandardItem(j.get("notes","")),
            ]
            self.model.appendRow(row)

    def send_finals(self):
        idx = self.table.currentIndex()
        if not idx.isValid(): return
        job_id = self.model.item(idx.row(), 0).text()
        # locate job
        job = None
        for j in load_jobs():
            if j.get("id") == job_id:
                job = j; break
        if not job:
            return
        try:
            paths = [Path(p) for p in job["final_paths"] if Path(p).exists()]
            if not paths:
                QtWidgets.QMessageBox.warning(self, "Finals", "Final files not found.")
                return
            out_dir = Path(job.get("out_dir", self.default_out_dir))
            stamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
            zip_name = f"{job.get('zip_base','images')}_finals_{stamp}.zip"
            method = job.get("method")
            link = None
            if method == "transfer.sh":
                zp = local_zip(paths, out_dir, zip_name)
                ok, link = transfer_sh(zp)
            elif method == "file.io":
                zp = local_zip(paths, out_dir, zip_name)
                ok, link = file_io(zp)
            elif method == "s3":
                acc = load_accounts().get("s3")
                zp = local_zip(paths, out_dir, zip_name)
                ok, link = s3_presign_and_upload(zp,
                    access_key=acc["access_key"], secret_key=acc["secret_key"],
                    bucket=acc["bucket"], key_prefix=job.get("s3_prefix","uploads"),
                    region=acc.get("region","auto"), endpoint_url=acc.get("endpoint_url"),
                    expires=int(job.get("expires_sec", 7*24*3600)))
            elif method == "gdrive":
                if not have_google_drive():
                    QtWidgets.QMessageBox.warning(self, "Google Drive", "Not connected.")
                    return
                zp = local_zip(paths, out_dir, zip_name)
                ok, link = gdrive_upload_zip(zp, get_google_token_path())
            elif method == "dropbox":
                acc = load_accounts().get("dropbox", {})
                zp = local_zip(paths, out_dir, zip_name)
                ok, link = dropbox_upload_zip(zp, acc.get("access_token",""))
            elif method == "onedrive":
                acc = load_accounts().get("onedrive", {})
                zp = local_zip(paths, out_dir, zip_name)
                ok, link = onedrive_upload_zip(zp, acc.get("access_token",""))
            else:
                QtWidgets.QMessageBox.information(self, "Finals", "Unknown method.")
                return

            if ok:
                QtWidgets.QApplication.clipboard().setText(link)
                QtWidgets.QMessageBox.information(self, "Finals", f"Final link copied:\n{link}")
                mark_completed(job_id)
                self.refresh()
            else:
                QtWidgets.QMessageBox.warning(self, "Finals", f"Failed: {link}")
        except Exception as e:
            QtWidgets.QMessageBox.warning(self, "Finals", f"Error: {e}")
