# src/batch_image_studio/cloud_folder_picker.py
from __future__ import annotations
from PySide6 import QtWidgets, QtGui, QtCore
from pathlib import Path

class CloudFolderPicker(QtWidgets.QDialog):
    """
    Generic tree-based cloud folder picker. You pass a "backend" object that exposes:
      - name: str (e.g., "Google Drive")
      - list_children(parent_id: str | None) -> list[dict] with keys: id, name, is_folder
      - roots() -> list[dict] like list_children(None)
    """
    def __init__(self, backend):
        super().__init__()
        self.backend = backend
        self.setWindowTitle(f"Choose Folder — {backend.name}")
        self.resize(520, 600)

        self.tree = QtWidgets.QTreeWidget()
        self.tree.setHeaderHidden(True)
        self.tree.itemExpanded.connect(self.on_expand)

        self.status = QtWidgets.QLabel("")
        btns = QtWidgets.QDialogButtonBox(QtWidgets.QDialogButtonBox.Ok | QtWidgets.QDialogButtonBox.Cancel)
        btns.accepted.connect(self.accept)
        btns.rejected.connect(self.reject)

        lay = QtWidgets.QVBoxLayout(self)
        lay.addWidget(self.tree, 1)
        lay.addWidget(self.status)
        lay.addWidget(btns)

        self.populate_roots()

    def populate_roots(self):
        self.tree.clear()
        try:
            roots = self.backend.roots()
            for node in roots:
                item = self._make_item(node)
                self.tree.addTopLevelItem(item)
        except Exception as e:
            self.status.setText(f"Error: {e}")

    def _make_item(self, node):
        item = QtWidgets.QTreeWidgetItem([node.get("name","")])
        item.setData(0, QtCore.Qt.UserRole, node)
        item.setChildIndicatorPolicy(QtWidgets.QTreeWidgetItem.ShowIndicator if node.get("is_folder") else QtWidgets.QTreeWidgetItem.DontShowIndicator)
        item.setIcon(0, self.style().standardIcon(QtWidgets.QStyle.SP_DirIcon if node.get("is_folder") else QtWidgets.QStyle.SP_FileIcon))
        return item

    def on_expand(self, item):
        node = item.data(0, QtCore.Qt.UserRole) or {}
        if not node.get("is_folder"): return
        # If already populated, skip
        if item.childCount() > 0 and item.child(0).data(0, QtCore.Qt.UserRole) is not None:
            return
        # clear placeholder children
        item.takeChildren()
        try:
            children = self.backend.list_children(node.get("id"))
            for ch in children:
                child_item = self._make_item(ch)
                item.addChild(child_item)
        except Exception as e:
            self.status.setText(f"Error: {e}")

    def selected_folder_id(self):
        it = self.tree.currentItem()
        if not it: return None, None
        node = it.data(0, QtCore.Qt.UserRole) or {}
        if not node.get("is_folder"):
            # prefer parent folder
            p = it.parent()
            if p: 
                pnode = p.data(0, QtCore.Qt.UserRole) or {}
                return pnode.get("id"), pnode.get("name")
            return None, None
        return node.get("id"), node.get("name")


# ---- Backends ----
class DriveBackend:
    name = "Google Drive"
    def __init__(self, creds):
        self.creds = creds
        from googleapiclient.discovery import build
        self.service = build("drive", "v3", credentials=creds)

    def roots(self):
        # 'My Drive' root
        about = self.service.about().get(fields="rootFolderId").execute()
        rid = about["rootFolderId"]
        return [{"id": rid, "name": "My Drive", "is_folder": True}]

    def list_children(self, parent_id):
        q = f"'{parent_id}' in parents and trashed = false"
        res = self.service.files().list(q=q, fields="files(id, name, mimeType)", pageSize=200).execute()
        out = []
        for f in res.get("files", []):
            is_folder = f.get("mimeType","") == "application/vnd.google-apps.folder"
            out.append({"id": f["id"], "name": f["name"], "is_folder": is_folder})
        return out

class DropboxBackend:
    name = "Dropbox"
    def __init__(self, dbx):
        self.dbx = dbx

    def roots(self):
        return [{"id": "", "name": "Dropbox", "is_folder": True}]

    def list_children(self, parent_id):
        path = parent_id or ""
        res = self.dbx.files_list_folder(path)
        out = []
        for e in res.entries:
            if isinstance(e, type(res.entries[0]).__class__):
                pass
            # Distinguish via attributes
            is_folder = hasattr(e, "path_lower") and getattr(e, "name", None) and (e.__class__.__name__ == "FolderMetadata")
            name = getattr(e, "name", "")
            child_id = getattr(e, "path_lower", "") or f"/{name}"
            out.append({"id": child_id, "name": name, "is_folder": is_folder})
        return out

class OneDriveBackend:
    name = "OneDrive"
    def __init__(self, access_token: str):
        self.access_token = access_token

    def roots(self):
        # root is "root"
        return [{"id": "root", "name": "OneDrive", "is_folder": True}]

    def list_children(self, parent_id):
        import requests
        url = f"https://graph.microsoft.com/v1.0/me/drive/items/{parent_id}/children" if parent_id != "root" else "https://graph.microsoft.com/v1.0/me/drive/root/children"
        r = requests.get(url, headers={"Authorization": f"Bearer {self.access_token}"})
        r.raise_for_status()
        data = r.json()
        out = []
        for it in data.get("value", []):
            is_folder = "folder" in it
            out.append({"id": it["id"], "name": it["name"], "is_folder": is_folder})
        return out
