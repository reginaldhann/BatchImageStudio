# src/batch_image_studio/clients.py
from __future__ import annotations
from pathlib import Path
import json
from appdirs import user_data_dir

APP_NAME = "BatchImageStudio"
COMPANY = "YourCompany"

def _clients_path() -> Path:
    p = Path(user_data_dir(APP_NAME, COMPANY)); p.mkdir(parents=True, exist_ok=True)
    return p / "clients.json"

def load_clients() -> list[dict]:
    p = _clients_path()
    if p.exists():
        try:
            return json.loads(p.read_text(encoding="utf-8"))
        except Exception:
            return []
    return []

def save_clients(items: list[dict]):
    _clients_path().write_text(json.dumps(items, indent=2), encoding="utf-8")

def add_or_update_client(c: dict):
    items = load_clients()
    # unique by email
    for i, it in enumerate(items):
        if it.get("email","").lower() == c.get("email","").lower():
            items[i] = c
            save_clients(items); return
    items.append(c); save_clients(items)

def delete_client(email: str):
    items = [c for c in load_clients() if c.get("email","").lower() != (email or "").lower()]
    save_clients(items)
