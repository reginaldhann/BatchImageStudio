from pathlib import Path

PACKAGE_ROOT = Path(__file__).resolve().parent
APP_ROOT = PACKAGE_ROOT.parent.parent
ASSETS_DIR = APP_ROOT / "assets"
WATERMARKS_DIR = ASSETS_DIR / "watermarks"
ICONS_DIR = ASSETS_DIR / "icons"
