import json, datetime
from pathlib import Path
from appdirs import user_data_dir

APP_NAME = "BatchImageStudio"
COMPANY = "YourCompany"

TRIAL_DAYS = 7

def _license_path() -> Path:
    base = Path(user_data_dir(APP_NAME, COMPANY))
    base.mkdir(parents=True, exist_ok=True)
    return base / "license.json"

def get_trial_status():
    p = _license_path()
    data = {}
    if p.exists():
        try:
            data = json.loads(p.read_text(encoding="utf-8"))
        except Exception:
            data = {}
    if "first_run" not in data:
        data["first_run"] = datetime.date.today().isoformat()
        p.write_text(json.dumps(data, indent=2), encoding="utf-8")

    first = datetime.date.fromisoformat(data["first_run"])
    days_used = (datetime.date.today() - first).days
    remaining = max(0, TRIAL_DAYS - days_used)
    is_expired = remaining <= 0 and not data.get("license_key")
    return {"remaining_days": remaining, "expired": is_expired, "license_key": data.get("license_key")}

def apply_license(key: str) -> bool:
    # TODO: Replace with your online/offline validation
    valid = key and len(key) >= 12
    if valid:
        p = _license_path()
        p.write_text(json.dumps({"license_key": key}, indent=2), encoding="utf-8")
    return valid

def is_pro() -> bool:
    st = get_trial_status()
    key = st.get("license_key") or ""
    # Simple stub: keys that start with 'PRO-' or length >= 16 are considered Pro
    return bool(key) and (key.startswith("PRO-") or len(key) >= 16)
